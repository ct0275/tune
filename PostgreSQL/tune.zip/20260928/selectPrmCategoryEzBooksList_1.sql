/* com.ezwelesp.fo.product.rest.display.corner.mapper.query.CornerQueryMapper.selectPrmCategoryEzBooksList */
select
            prm.gds_cd
            ,prm.book_gds_cd
            ,prm.book_gds_nm
            ,prm.rps_autr_nm
            ,prm.real_sell_prc
            ,prm.nrml_sell_prc
            ,prm.dc_rt
            ,prm.gdsImgUrl
            ,prm.pbsh_co_nm
            ,prm.adltCrtfNeedYn
            ,prm.frst_reg_dtm
            ,prm.stsfOvrScor
            ,prm.rcmmCntSum
            ,prm.gdsrvwCnt
            ,prm.fvtGdsCnt
            ,prm.frstRegDtmMax
            ,prm.hezoStdCtgrWspAplyCd
            ,'CAT' as gdsDspBsicKndCd /* 상품전시기준종류코드 */
            ,9999 as stck_qty /*이지북스는 재로관리 하지 않음*/
             
        from
            (select
                b.gds_cd
                ,b.book_gds_cd
                ,b.book_gds_nm
                ,COALESCE(b.rps_autr_nm, '') as rps_autr_nm
                ,b.real_sell_prc
                ,b.nrml_sell_prc
                ,b.dc_rt
                ,b.gds_rps_img_url as gdsImgUrl
                ,b.pbsh_co_nm
                ,b.adlt_ctgr_book_yn as adltCrtfNeedYn
                ,b.frst_reg_dtm
                ,b.stck_qty
                ,COALESCE(
                    (SELECT SUM(stsf_ovr_scor)/count(gds_cd)
                    FROM ez_pd.pd_book_gdsrvw_b pbgb
                    WHERE pbgb.gds_cd = b.gds_cd
                        AND use_yn = 'Y'
                        AND exps_yn = 'Y'
                    GROUP BY pbgb.gds_cd), '0') AS stsfOvrScor /*만족도총평점수*/
                ,COALESCE(
                    (SELECT SUM(rcmm_cnt)
                    FROM ez_pd.pd_book_gdsrvw_b pbgb
                    WHERE pbgb.gds_cd = b.gds_cd
                        AND use_yn = 'Y'
                        AND exps_yn = 'Y'
                    GROUP BY pbgb.gds_cd), '0') AS rcmmCntSum /*추천수*/
                ,cast(COALESCE(
                    (SELECT
                        CASE
                            WHEN COUNT(1)  <  1000 THEN TO_CHAR(COUNT(1), 'FM999,999') /*1~999*/
                            WHEN COUNT(1)  <  10000 THEN TO_CHAR(ROUND(COUNT(1) / 1000.0, 2), 'FM999,999') /*1000~9999 -> 천 단위*/
                            ELSE CONCAT(TO_CHAR(ROUND(COUNT(1) / 10000.0, 2), 'FM999,999'), '만') /*10000 이상 -> 만 단위*/
                        END
                    FROM ez_pd.pd_book_gdsrvw_b pbgb
                    WHERE pbgb.gds_cd = b.gds_cd
                        AND use_yn = 'Y'
                        AND exps_yn = 'Y'
                    GROUP BY pbgb.gds_cd), '0')as numeric) AS gdsrvwCnt /* 리뷰수 */
                ,COALESCE(
                    (SELECT
                        CASE
                            WHEN COUNT(1)  <  1000 THEN TO_CHAR(COUNT(1), 'FM999,999') /*1~999*/
                            WHEN COUNT(1)  <  10000 THEN TO_CHAR(ROUND(COUNT(1) / 1000.0, 2), 'FM999,999') /*1000~9999 -> 천 단위*/
                            ELSE CONCAT(TO_CHAR(ROUND(COUNT(1) / 10000.0, 2), 'FM999,999'), '만') /*10000 이상 -> 만 단위*/
                        END
                    FROM ez_pd.pd_fvt_gds_b fgb
                    WHERE fgb.gds_cd = b.gds_cd
                        AND fgb.fvt_gds_typ_cd = 'GOD'
                    GROUP BY gds_cd), '0') AS fvtGdsCnt /*찜 수*/
                ,COALESCE(
                    (SELECT MAX(frst_reg_dtm)
                    FROM ez_pd.pd_book_gdsrvw_b pbgb
                    WHERE pbgb.gds_cd = b.gds_cd
                        AND use_yn = 'Y'
                        AND exps_yn = 'Y'
                    GROUP BY pbgb.gds_cd LIMIT 1), '') AS frstRegDtmMax /*등록순*/
                ,scr.hezo_std_ctgr_wsp_aply_cd as hezoStdCtgrWspAplyCd /* 복지몰표준카테고리복지제도포인트적용코드 */
                 
                 
            from ez_pd.pd_book_gds_c b
                inner join ez_pd.pd_book_gds_dsp_ctgr_d scd on scd.gds_cd = b.gds_cd and scd.use_yn = 'Y'
                inner join ez_dp.dp_hezo_std_ctgr_r scr on scr.hezo_std_ctgr_cd = scd.dsp_std_ctgr_cd and scr.hezo_no =  378
                inner join ez_dp.dp_std_ctgr_b scb on scb.std_ctgr_cd = scd.dsp_std_ctgr_cd
                 

            where 1 = 1
                and b.book_gds_sell_st_cd = '1001'
                and b.use_yn = 'Y'
                AND scd.use_yn = 'Y'
                AND scr.use_yn = 'Y'
                AND scb.use_yn = 'Y'
                AND scb.dsp_exps_yn = 'Y'
                 
                        and scr.hezo_std_ctgr_cd LIKE '08%'
                     


                 
                 
                 
                 
                    ORDER BY b.frst_reg_dtm DESC
                 
                 
                 

        --) prm LIMIT 20
		) prm