[PRD] ezweladm@ezwel> \sf ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt
CREATE OR REPLACE PROCEDURE ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt(IN i_clntcd character varying[], OUT o_result character varying)
 LANGUAGE plpgsql
AS $procedure$
    /**********************************************************************
     * Id : BA_HICA00021
     * Name : 고객사정산(온라인특별포인트) 이관 일배치
     * Description : 
     **********************************************************************
     * Input Parameters
     *---------------------------------------------------------------------
     * i_clntcd        IN        VARCHAR[]        고객사코드 리스트
     **********************************************************************
     * Output Parameters
     *---------------------------------------------------------------------
     * o_result        OUT        VARCHAR        결과문자값 (성공:OK / 그외:오류)
     **********************************************************************
     * Example
     *---------------------------------------------------------------------
     * 1. call ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt(null, null);
     * 2. call ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt(array['ezwel','...'], null);
     **********************************************************************
     * Change History
     *---------------------------------------------------------------------
     *    Date        Author      Description
     *---------------------------------------------------------------------
     * 2026-02-12     heg020        최초 생성
     * 2026-02-13     heg020        튜닝적용
     **********************************************************************/
    declare
        v_clock_time timestamp(0);
        v_usr_id varchar := 'BATCH';
        v_pgm_id varchar := 'BA_HICA00021';
        v_curr_ym varchar := to_char(clock_timestamp(), 'yyyymm');
        v_clntcd_arr text[]; -- 고객사 배열
        v_dfns_ym varchar := '202607';
        v_prev01_dd_dt varchar := to_char(current_date - 1, 'yyyymmdd');
--        v_dfns_ym varchar := (select comm_dtl_cd_nm
--                                from ez_cm.cm_comm_dtl_c
--                               where comm_cd = 'stl_open_ym_cd'
--                                 and comm_dtl_cd = '01'); -- TODO 해당월 이후에만 데이터 삭제 및 생성 (방어로직용)
--        v_pk numeric := 0;
        v_min_stl_strt_dt varchar := null; -- ez_or.or_ord_gds_amt_d 성능개선 관련 기본 조건
    begin
        
--        PERFORM set_config('max_parallel_workers_per_gather', '4', true);
--        PERFORM set_config('max_parallel_workers', '16', true);
--        PERFORM set_config('parallel_setup_cost', '0', true);
--        PERFORM set_config('parallel_tuple_cost', '0', true);
--        PERFORM set_config('min_parallel_table_scan_size', '0', true);
--        PERFORM set_config('min_parallel_index_scan_size', '0', true);
--        PERFORM set_config('work_mem', '1GB', true);

        -- i_clntcd 가 null (전체 고객사 실행) 일 때만 병렬 옵션 및 메모리 상향 
        IF i_clntcd IS NULL THEN
            PERFORM set_config('max_parallel_workers_per_gather', '8', true);
            PERFORM set_config('parallel_setup_cost', '0', true);
            PERFORM set_config('parallel_tuple_cost', '0', true);
            PERFORM set_config('work_mem', '128MB', true);
			
			PERFORM oper.pg_prewarm('ez_or.or_ord_gds_amt_d'::regclass);
			PERFORM oper.pg_prewarm('ez_ca.ca_spp_use_l'::regclass);
        END IF;
        
        --======= i_clntcd 가 null 이면 전체 고객사 배열로 대체 =======
        v_clntcd_arr := coalesce(i_clntcd, array(select clnt_cd from ez_ct.ct_clnt_b));
        
        select min(s.stl_strt_dt) as stl_strt_dt
          into v_min_stl_strt_dt
          from ez_ca.ca_clnt_stl_cycl_term_b s
         where s.cnfm_yn = 'N'
           and s.stl_onln_ofln_div_cd = '01'
           and s.stl_ym <= v_curr_ym
           and s.stl_ym >= v_dfns_ym -- TODO 방어로직
           and s.stl_strt_dt <= v_prev01_dd_dt
           and s.clnt_cd = any(v_clntcd_arr);
        
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure Start, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), 'START';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure Start', -- 프로시저명
--            format('sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure Start, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), 'START'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        /************************************************************************
         * 01.특별포인트사용내역 데이터 갱신
         * 
         * 특별 포인트 온라인 소멸금액(EXPIRE_AMT) 업데이트
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-01, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '01.특별포인트사용내역 데이터 갱신';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-01', -- 프로시저명
--            format('step-01, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '01.특별포인트사용내역 데이터 갱신'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        merge into ez_ca.ca_spp_use_l target
        using (select a.spp_grnt_seq
                    , a.spp_use_seq
                    , coalesce(b.rgm_clsg_aft_pnt_extn_amt, 0) as rgm_clsg_aft_pnt_extn_amt
                 from ez_ca.ca_spp_use_l a
                inner join ez_ca.ca_spp_use_clsg_stl_l b
                   on a.spp_grnt_seq = b.spp_grnt_seq
                  and a.spp_use_seq = b.spp_use_seq
                  and a.clnt_cd = any(v_clntcd_arr)
                where (b.rgm_clsg_aft_pnt_extn_dtm is not null or coalesce(b.rgm_clsg_aft_pnt_extn_amt, 0) <> 0)
              ) source
           on target.spp_grnt_seq = source.spp_grnt_seq
          and target.spp_use_seq = source.spp_use_seq
         when matched then
            update set spp_extn_amt = source.rgm_clsg_aft_pnt_extn_amt
                     , last_mod_dtm = to_char(v_clock_time, 'yyyymmddhh24miss')
                     , last_mod_usr_id =  v_usr_id
                     , last_mod_pgm_id = v_pgm_id;
        
        /************************************************************************
         * 02.월정산특별포인트기본 데이터 삭제
         * 
         * 특별 포인트 온라인 주문 삭제 관련
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-02, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '02.월정산특별포인트기본 데이터 삭제';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-02', -- 프로시저명
--            format('step-02, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '02.월정산특별포인트기본 데이터 삭제'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        delete from ez_ca.ca_mm_stl_spp_b a
         where exists (select 1
                         from ez_ca.ca_clnt_stl_cycl_term_b s
                        where s.stl_onln_ofln_div_cd = '01'
                          and s.cnfm_yn = 'N'
                          and s.stl_ym <= v_curr_ym
                          and s.stl_ym >= v_dfns_ym -- TODO 방어로직
                          and s.clnt_cd = any(v_clntcd_arr)
                          and s.stl_cycl_seq = a.stl_cycl_seq
                          and s.stl_strt_dt <= v_prev01_dd_dt);
        
        /************************************************************************
         * 03.월정산특별포인트기본 데이터 생성
         * 
         * 특별 포인트 온라인 주문 관련
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-03, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '03.월정산특별포인트기본 데이터 생성';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-03', -- 프로시저명
--            format('step-03, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '03.월정산특별포인트기본 데이터 생성'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        insert into ez_ca.ca_mm_stl_spp_b (
            spp_sum_seq
            , spp_use_poss_div_cd
            , spp_knd_cd
            , spp_pymt_amt
            , mm_stl_seq
            , wsp_cd
            , stl_cycl_seq
            , spp_stl_yn
            , hifi_slip_put_obj_yn
            , spp_extn_amt
            , frst_reg_dtm
            , frst_reg_usr_id
            , frst_reg_pgm_id
            , last_mod_dtm
            , last_mod_usr_id
            , last_mod_pgm_id
        )
        with base_cyclterm as materialized (
            select distinct
                   s1.ord_no
                 , s1.pymt_nos
                 , s3.stl_cycl_seq
              from ez_or.or_ord_gds_amt_d s1
             inner join (select s.clnt_cd
                              , s.stl_cycl_seq
                              , s.stl_strt_dt
                              , s.stl_end_dt
                           from ez_ca.ca_clnt_stl_cycl_term_b s
                          where s.cnfm_yn = 'N'
                            and s.stl_onln_ofln_div_cd = '01'
                            and s.stl_strt_dt <= v_prev01_dd_dt
                            and s.stl_ym >= v_dfns_ym -- TODO 방어로직
                            and s.clnt_cd = any(v_clntcd_arr)
                            and s.stl_strt_dt >= v_min_stl_strt_dt) s3
                on s1.clnt_stl_prcs_strt_dtm between s3.stl_strt_dt || '000000' and s3.stl_end_dt || '235959'
               and s1.clnt_cd = s3.clnt_cd
        ), max_seq as (
            select coalesce(max(spp_sum_seq), 1) as max_seq
              from ez_ca.ca_mm_stl_spp_b
        )
        select m.max_seq + row_number() over() as spp_sum_seq
             , c.spp_use_poss_div_cd as spp_use_poss_div_cd
             , c.spp_knd_cd as spp_knd_cd
             , c.use_pnt as spp_pymt_amt
             , a.mm_stl_onln_seq as mm_stl_seq
             , c.cc_pnt_knd_cd as wsp_cd
             , a.stl_cycl_seq as stl_cycl_seq
             , coalesce(e.spp_stl_prcs_yn, 'Y') as spp_stl_yn
             , coalesce(e.hifi_slip_put_yn, 'Y') as hifi_slip_put_obj_yn
             , c.spp_extn_amt as spp_extn_amt
             , to_char(v_clock_time, 'yyyymmddhh24miss') as frst_reg_dtm
             , v_usr_id as frst_reg_usr_id
             , v_pgm_id as frst_reg_pgm_id
             , to_char(v_clock_time, 'yyyymmddhh24miss') as last_mod_dtm
             , v_usr_id as last_mod_usr_id
             , v_pgm_id as last_mod_pgm_id
          from (select ord_no
                     , pymt_nos
                     , stl_cycl_seq
                  from base_cyclterm       -- 튜닝변경
                 order by ord_no, pymt_nos -- 튜닝변경
                offset 0) b                -- 튜닝변경
         inner join lateral (select a.ord_no
                                  , a.pymt_nos
                                  , a.pymt_amt_blng_yn -- 'Y':청구,'N':미청구 (default:청구)
                                  , sum(case when a.pymt_mns_cd = '1001' then coalesce(a.pymt_amt, 0) -- 포인트 결제
                                             else 0
                                         end) as point
                                  , sum(case when a.pymt_mns_cd = '1008' then coalesce(a.pymt_amt, 0) -- 특별포인트 결제
                                             else 0
                                         end) as special
                                  , sum(case when a.pymt_mns_cd = '1004' then coalesce(a.pymt_amt, 0) -- 급여차감 결제
                                             else 0
                                         end) as balance
                                  , sum(case when a.pymt_mns_cd in ('1017','1018') then coalesce(a.pymt_amt, 0) -- 신청형:1017,승인형:1018 (후불결제금액)
                                             else 0
                                         end) as def_amt
                                  , sum(case when a.pymt_mns_cd = '1012' and pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- 쿠폰
                                             else 0
                                         end) as coupon
                                  , sum(case when a.pymt_mns_cd = '1012' and pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- 복지쿠폰 결제
                                             else 0
                                         end) as clt_coupon
                                  , sum(case when a.pymt_mns_cd = '9998' then coalesce(a.pymt_amt, 0) -- 현장 결제
                                             else 0
                                         end) as etc
                                  , sum(case when a.pymt_mns_cd = '1003' then coalesce(a.pymt_amt, 0) -- 실시간 계좌이체
                                             else 0
                                         end) as trans
                                  , sum(case when a.pymt_mns_cd = '1002' then coalesce(a.pymt_amt, 0) -- 신용카드 결제
                                             else 0
                                         end) as card
                                  , sum(case when a.pymt_mns_cd = '1010' then coalesce(a.pymt_amt, 0) -- 무통장입금
                                             else 0
                                         end) as virtual_amt
                                  , sum(case when a.pymt_mns_cd = '1013' then coalesce(a.pymt_amt, 0) -- 휴대폰 결제
                                             else 0
                                         end) as mpay_amt
                                  , sum(case when a.pymt_mns_cd = '1014' then coalesce(a.pymt_amt, 0) -- 할부금융 결제(에큐온결제금액)
                                             else 0
                                         end) as acuon_amt
                                  , sum(case when a.pymt_mns_cd = '1015' then coalesce(a.pymt_amt, 0) -- 코나아이포인트결제금액
                                             else 0
                                         end) as konai_amt
                                  , sum(case when a.pymt_mns_cd in ('1016','1019') then coalesce(a.pymt_amt, 0) -- 제로페이
                                             else 0
                                         end) as zeropay
                                  , sum(case when a.pymt_mns_cd = '2000' then coalesce(a.pymt_amt, 0) -- 지역화폐
                                             else 0
                                         end) as local_pay_amt
                                  , sum(case when a.pymt_mns_cd = '1020' and a.pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- H.Point(충전)
                                             else 0
                                         end) as h_point_ch
                                  , sum(case when a.pymt_mns_cd = '1020' and a.pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- H.Point(적립)
                                             else 0
                                         end) as h_point_add
                                  , sum(case when a.pymt_mns_cd = '1023' and a.pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- NH포인트(충전)
                                             else 0
                                         end) as chrg_nhpoint
                                  , sum(case when a.pymt_mns_cd = '1023' and a.pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- NH포인트(적립)
                                             else 0
                                         end) as add_nhpoint
                                  , sum(case when a.pymt_mns_cd = '1022' then coalesce(a.pymt_amt, 0) -- 네이버페이
                                             else 0
                                         end) as naver_pay
                                  , sum(case when a.pymt_mns_cd = '1024' then coalesce(a.pymt_amt, 0) -- 복지플랫폼포인트
                                             else 0
                                         end) as korcham_amt
                                  , sum(case when a.pymt_mns_cd = '1025' then coalesce(a.pymt_amt, 0) -- 복지대장포인트
                                             else 0
                                         end) as dj_point
                                  , sum(case when a.pymt_mns_cd = '1026' then coalesce(a.pymt_amt, 0) -- 대장페이포인트
                                             else 0
                                         end) as dj_pay_point
                                  , sum(case when a.pymt_mns_cd = '1027' then coalesce(a.pymt_amt, 0) -- 온누리페이
                                             else 0
                                         end) as onnuri_pay
                                  , sum(case when a.pymt_mns_cd = '1028' then coalesce(a.pymt_amt, 0) -- 우체국포인트
                                             else 0
                                         end) as post_point
                                  , sum(case when a.pymt_mns_cd = '1006' then coalesce(a.pymt_amt, 0) -- 적립금포인트
                                             else 0
                                         end) as mlg_amt
                                  , sum(case when a.pymt_mns_cd = '1007' then coalesce(a.pymt_amt, 0) -- 우리모아포인트
                                             else 0
                                         end) as wm_point
                                  , sum(case when a.pymt_mns_cd = '1029' then coalesce(a.pymt_amt, 0) -- 디지털온누리
                                             else 0
                                         end) as dgt_onpay_amt
                                  , sum(case when a.pymt_mns_cd = '1030' then coalesce(a.pymt_amt, 0) -- 한라포인트
                                             else 0
                                         end) as hl_point
                                  , sum(case when a.pymt_mns_cd = '1031' then coalesce(a.pymt_amt, 0) -- 한라포인트차지
                                             else 0
                                         end) as hl_point_chrg
                                  , sum(case when a.pymt_mns_cd = '1032' then coalesce(a.pymt_amt, 0) -- 대전사랑카드
                                             else 0
                                         end) as daejeon_love_crd
                                  , sum(case when a.pymt_mns_cd = '1033' then coalesce(a.pymt_amt, 0) -- 동백전
                                             else 0
                                         end) as dongbak_amt
                                  , sum(case when a.pymt_mns_cd = '1034' then coalesce(a.pymt_amt, 0) -- 경기도청년기본소득
                                             else 0
                                         end) as ng_youth_amt
                                  , sum(case when a.pymt_mns_cd = '1035' then coalesce(a.pymt_amt, 0) -- NH카드
                                             else 0
                                         end) as nh_card
                                  , sum(case when a.pymt_mns_cd = '1042' then coalesce(a.pymt_amt, 0) -- 교원멤버스복지포인트
                                                    else 0
                                                     end) as kw_pymt_amt         
                               from ez_ca.ca_mm_stl_ord_pymt_mns_l a
                              where a.ord_no = b.ord_no
                                and a.pymt_nos = b.pymt_nos
                              group by a.ord_no, a.pymt_nos, a.pymt_amt_blng_yn
                              order by a.ord_no, a.pymt_nos
                             offset 0) d
            on 1=1
         inner join ez_ca.ca_onln_mm_stl_b a
            on a.ord_no = b.ord_no
           and a.pymt_nos = b.pymt_nos
         inner join ez_ca.ca_spp_use_l c
            on a.ord_no = c.ord_no
           and a.user_key = c.user_key
          left outer join ez_ca.ca_stl_pnt_blng_slip_put_b e
            on c.clnt_cd = e.clnt_cd
           and c.cc_pnt_knd_cd = e.spp_knd_cd
           and c.spp_knd_cd = e.spp_grp_cd
           and e.spp_use_poss_div_cd in ('ON', 'ALL')
         cross join max_seq m
         where c.spp_use_cncl_div_cd = 'U' -- 사용
           and (d.point + d.special + d.balance + d.def_amt + d.coupon + d.clt_coupon + d.etc + d.trans + d.card + d.virtual_amt +
                d.mpay_amt + d.acuon_amt + d.konai_amt + d.zeropay + d.local_pay_amt + d.h_point_ch + d.h_point_add + d.chrg_nhpoint + d.add_nhpoint + d.naver_pay +
                d.korcham_amt + d.dj_point + d.dj_pay_point + d.onnuri_pay + d.post_point + d.mlg_amt + d.wm_point + d.dgt_onpay_amt + d.hl_point + d.hl_point_chrg + d.daejeon_love_crd + d.dongbak_amt +
                d.ng_youth_amt + d.nh_card + d.kw_pymt_amt) >= 0
           and c.spp_use_poss_div_cd = 'ON'
           and (e.spp_stl_prcs_yn is null or e.spp_stl_prcs_yn = d.pymt_amt_blng_yn);
        
        /************************************************************************
         * 04.월정산특별포인트기본 데이터 생성
         * 
         * 특별 포인트 온라인 취소 관련
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-04, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '04.월정산특별포인트기본 데이터 생성';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-04', -- 프로시저명
--            format('step-04, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '04.월정산특별포인트기본 데이터 생성'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        insert into ez_ca.ca_mm_stl_spp_b (
            spp_sum_seq
            , spp_use_poss_div_cd
            , spp_knd_cd
            , spp_pymt_amt
            , mm_stl_seq
            , wsp_cd
            , stl_cycl_seq
            , spp_stl_yn
            , hifi_slip_put_obj_yn
            , spp_extn_amt
            , frst_reg_dtm
            , frst_reg_usr_id
            , frst_reg_pgm_id
            , last_mod_dtm
            , last_mod_usr_id
            , last_mod_pgm_id
        )
        with base_cyclterm as materialized (
            select distinct
                   s1.ord_no
                 , s1.pymt_nos
                 , s3.stl_cycl_seq
              from ez_or.or_ord_gds_amt_d s1
             inner join (select s.clnt_cd
                              , s.stl_cycl_seq
                              , s.stl_strt_dt
                              , s.stl_end_dt
                           from ez_ca.ca_clnt_stl_cycl_term_b s
                          where s.cnfm_yn = 'N'
                            and s.stl_onln_ofln_div_cd = '01'
                            and s.stl_strt_dt <= v_prev01_dd_dt
                            and s.stl_ym >= v_dfns_ym -- TODO 방어로직
                            and s.clnt_cd = any(v_clntcd_arr)
                            and s.stl_strt_dt >= v_min_stl_strt_dt) s3
                on s1.clnt_stl_prcs_strt_dtm between s3.stl_strt_dt || '000000' and s3.stl_end_dt || '235959'
               and s1.clnt_cd = s3.clnt_cd
        ), max_seq as (
            select coalesce(max(spp_sum_seq), 1) as max_seq
              from ez_ca.ca_mm_stl_spp_b
        )
        select m.max_seq + row_number() over() as spp_sum_seq
             , c.spp_use_poss_div_cd as spp_use_poss_div_cd
             , c.spp_knd_cd as spp_knd_cd
             , c.use_pnt as spp_pymt_amt
             , a.mm_stl_onln_seq as mm_stl_seq
             , c.cc_pnt_knd_cd as wsp_cd
             , a.stl_cycl_seq as stl_cycl_seq
             , coalesce(e.spp_stl_prcs_yn, 'Y') as spp_stl_yn
             , coalesce(e.hifi_slip_put_yn, 'Y') as hifi_slip_put_obj_yn
             , c.spp_extn_amt as spp_extn_amt
             , to_char(v_clock_time, 'yyyymmddhh24miss') as frst_reg_dtm
             , v_usr_id as frst_reg_usr_id
             , v_pgm_id as frst_reg_pgm_id
             , to_char(v_clock_time, 'yyyymmddhh24miss') as last_mod_dtm
             , v_usr_id as last_mod_usr_id
             , v_pgm_id as last_mod_pgm_id
          from (select s.ord_no
                     , s.pymt_nos
                     , s.stl_cycl_seq
                  from base_cyclterm s         -- 튜닝변경
                 order by s.ord_no, s.pymt_nos -- 튜닝변경
                offset 0) b                    -- 튜닝변경
         inner join lateral (select a.ord_no
                                  , a.pymt_nos
                                  , a.pymt_amt_blng_yn -- 'Y':청구,'N':미청구 (default:청구)
                                  , sum(case when a.pymt_mns_cd = '1001' then coalesce(a.pymt_amt, 0) -- 포인트 결제
                                             else 0
                                         end) as point
                                  , sum(case when a.pymt_mns_cd = '1008' then coalesce(a.pymt_amt, 0) -- 특별포인트 결제
                                             else 0
                                         end) as special
                                  , sum(case when a.pymt_mns_cd = '1004' then coalesce(a.pymt_amt, 0) -- 급여차감 결제
                                             else 0
                                         end) as balance
                                  , sum(case when a.pymt_mns_cd in ('1017','1018') then coalesce(a.pymt_amt, 0) -- 신청형:1017,승인형:1018 (후불결제금액)
                                             else 0
                                         end) as def_amt
                                  , sum(case when a.pymt_mns_cd = '1012' and pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- 쿠폰
                                             else 0
                                         end) as coupon
                                  , sum(case when a.pymt_mns_cd = '1012' and pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- 복지쿠폰 결제
                                             else 0
                                         end) as clt_coupon
                                  , sum(case when a.pymt_mns_cd = '9998' then coalesce(a.pymt_amt, 0) -- 현장 결제
                                             else 0
                                         end) as etc
                                  , sum(case when a.pymt_mns_cd = '1003' then coalesce(a.pymt_amt, 0) -- 실시간 계좌이체
                                             else 0
                                         end) as trans
                                  , sum(case when a.pymt_mns_cd = '1002' then coalesce(a.pymt_amt, 0) -- 신용카드 결제
                                             else 0
                                         end) as card
                                  , sum(case when a.pymt_mns_cd = '1010' then coalesce(a.pymt_amt, 0) -- 무통장입금
                                             else 0
                                         end) as virtual_amt
                                  , sum(case when a.pymt_mns_cd = '1013' then coalesce(a.pymt_amt, 0) -- 휴대폰 결제
                                             else 0
                                         end) as mpay_amt
                                  , sum(case when a.pymt_mns_cd = '1014' then coalesce(a.pymt_amt, 0) -- 할부금융 결제(에큐온결제금액)
                                             else 0
                                         end) as acuon_amt
                                  , sum(case when a.pymt_mns_cd = '1015' then coalesce(a.pymt_amt, 0) -- 코나아이포인트결제금액
                                             else 0
                                         end) as konai_amt
                                  , sum(case when a.pymt_mns_cd in ('1016','1019') then coalesce(a.pymt_amt, 0) -- 제로페이
                                             else 0
                                         end) as zeropay
                                  , sum(case when a.pymt_mns_cd = '2000' then coalesce(a.pymt_amt, 0) -- 지역화폐
                                             else 0
                                         end) as local_pay_amt
                                  , sum(case when a.pymt_mns_cd = '1020' and a.pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- H.Point(충전)
                                             else 0
                                         end) as h_point_ch
                                  , sum(case when a.pymt_mns_cd = '1020' and a.pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- H.Point(적립)
                                             else 0
                                         end) as h_point_add
                                  , sum(case when a.pymt_mns_cd = '1023' and a.pymt_mns_cd_lval = '1001' then coalesce(a.pymt_amt, 0) -- NH포인트(충전)
                                             else 0
                                         end) as chrg_nhpoint
                                  , sum(case when a.pymt_mns_cd = '1023' and a.pymt_mns_cd_lval = '1000' then coalesce(a.pymt_amt, 0) -- NH포인트(적립)
                                             else 0
                                         end) as add_nhpoint
                                  , sum(case when a.pymt_mns_cd = '1022' then coalesce(a.pymt_amt, 0) -- 네이버페이
                                             else 0
                                         end) as naver_pay
                                  , sum(case when a.pymt_mns_cd = '1024' then coalesce(a.pymt_amt, 0) -- 복지플랫폼포인트
                                             else 0
                                         end) as korcham_amt
                                  , sum(case when a.pymt_mns_cd = '1025' then coalesce(a.pymt_amt, 0) -- 복지대장포인트
                                             else 0
                                         end) as dj_point
                                  , sum(case when a.pymt_mns_cd = '1026' then coalesce(a.pymt_amt, 0) -- 대장페이포인트
                                             else 0
                                         end) as dj_pay_point
                                  , sum(case when a.pymt_mns_cd = '1027' then coalesce(a.pymt_amt, 0) -- 온누리페이
                                             else 0
                                         end) as onnuri_pay
                                  , sum(case when a.pymt_mns_cd = '1028' then coalesce(a.pymt_amt, 0) -- 우체국포인트
                                             else 0
                                         end) as post_point
                                  , sum(case when a.pymt_mns_cd = '1006' then coalesce(a.pymt_amt, 0) -- 적립금포인트
                                             else 0
                                         end) as mlg_amt
                                  , sum(case when a.pymt_mns_cd = '1007' then coalesce(a.pymt_amt, 0) -- 우리모아포인트
                                             else 0
                                         end) as wm_point
                                  , sum(case when a.pymt_mns_cd = '1029' then coalesce(a.pymt_amt, 0) -- 디지털온누리
                                             else 0
                                         end) as dgt_onpay_amt
                                  , sum(case when a.pymt_mns_cd = '1030' then coalesce(a.pymt_amt, 0) -- 한라포인트
                                             else 0
                                         end) as hl_point
                                  , sum(case when a.pymt_mns_cd = '1031' then coalesce(a.pymt_amt, 0) -- 한라포인트차지
                                             else 0
                                         end) as hl_point_chrg
                                  , sum(case when a.pymt_mns_cd = '1032' then coalesce(a.pymt_amt, 0) -- 대전사랑카드
                                             else 0
                                         end) as daejeon_love_crd
                                  , sum(case when a.pymt_mns_cd = '1033' then coalesce(a.pymt_amt, 0) -- 동백전
                                             else 0
                                         end) as dongbak_amt
                                  , sum(case when a.pymt_mns_cd = '1034' then coalesce(a.pymt_amt, 0) -- 경기도청년기본소득
                                             else 0
                                         end) as ng_youth_amt
                                  , sum(case when a.pymt_mns_cd = '1035' then coalesce(a.pymt_amt, 0) -- NH카드
                                             else 0
                                         end) as nh_card
                                  , sum(case when a.pymt_mns_cd = '1042' then coalesce(a.pymt_amt, 0) -- 교원멤버스복지포인트
                                             else 0
                                         end) as kw_pymt_amt
                               from ez_ca.ca_mm_stl_ord_pymt_mns_l a 
                              where a.ord_no = b.ord_no
                                and a.pymt_nos = b.pymt_nos
                              group by a.ord_no, a.pymt_nos, a.pymt_amt_blng_yn
                              order by a.ord_no, a.pymt_nos
                             offset 0) d
            on 1=1
         inner join ez_ca.ca_onln_mm_stl_b a
            on a.ord_no = b.ord_no
           and a.pymt_nos = b.pymt_nos
         inner join ez_ca.ca_spp_use_l c
            on a.ord_no = c.ord_no
           and a.user_key = c.user_key
          left outer join ez_ca.ca_stl_pnt_blng_slip_put_b e
            on c.clnt_cd = e.clnt_cd
           and c.cc_pnt_knd_cd = e.spp_knd_cd
           and c.spp_knd_cd = e.spp_grp_cd
           and e.spp_use_poss_div_cd in ('ON', 'ALL')
         cross join max_seq m
         where c.spp_use_cncl_div_cd = 'C' -- 취소
           and (d.point + d.special + d.balance + d.def_amt + d.coupon + d.clt_coupon + d.etc + d.trans + d.card + d.virtual_amt +
                d.mpay_amt + d.acuon_amt + d.konai_amt + d.zeropay + d.local_pay_amt + d.h_point_ch + d.h_point_add + d.chrg_nhpoint + d.add_nhpoint + d.naver_pay +
                d.korcham_amt + d.dj_point + d.dj_pay_point + d.onnuri_pay + d.post_point + d.mlg_amt + d.wm_point + d.dgt_onpay_amt + d.hl_point + d.hl_point_chrg + d.daejeon_love_crd + d.dongbak_amt +
                d.ng_youth_amt + d.nh_card+ d.kw_pymt_amt) < 0
           and c.spp_use_poss_div_cd = 'ON'
           and (e.spp_stl_prcs_yn is null or e.spp_stl_prcs_yn = d.pymt_amt_blng_yn);
        
        /************************************************************************
         * 05.월정산특별포인트기본 데이터 생성 (이지웰페이)
         *
         * 특별 포인트 직결제 주문 관련
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-05, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '05.월정산특별포인트기본 데이터 생성';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-05', -- 프로시저명
--            format('step-05, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '05.월정산특별포인트기본 데이터 생성'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        insert into ez_ca.ca_mm_stl_spp_b (
            spp_sum_seq
            , spp_use_poss_div_cd
            , spp_knd_cd
            , spp_pymt_amt
            , mm_stl_seq
            , wsp_cd
            , stl_cycl_seq
            , spp_stl_yn
            , hifi_slip_put_obj_yn
            , frst_reg_dtm
            , frst_reg_usr_id
            , frst_reg_pgm_id
            , last_mod_dtm
            , last_mod_usr_id
            , last_mod_pgm_id
        )
        with base_cyclterm as materialized (
            select distinct
                   s1.ord_no
                 , s1.pymt_nos
                 , s3.stl_cycl_seq
              from ez_or.or_ord_gds_amt_d s1
             inner join (select s.clnt_cd
                              , s.stl_cycl_seq
                              , s.stl_strt_dt
                              , s.stl_end_dt
                           from ez_ca.ca_clnt_stl_cycl_term_b s
                          where s.cnfm_yn = 'N'
                            and s.stl_onln_ofln_div_cd = '01'
                            and s.stl_strt_dt <= v_prev01_dd_dt
                            and s.stl_ym >= v_dfns_ym -- TODO 방어로직
                            and s.clnt_cd = any(v_clntcd_arr)
                            and s.stl_strt_dt >= v_min_stl_strt_dt) s3
                on s1.clnt_stl_prcs_strt_dtm between s3.stl_strt_dt || '000000' and s3.stl_end_dt || '235959'
               and s1.clnt_cd = s3.clnt_cd
        ), max_seq as (
            select coalesce(max(spp_sum_seq), 1) as max_seq
              from ez_ca.ca_mm_stl_spp_b
        )
        select m.max_seq + row_number() over() as spp_sum_seq
             , c.spp_use_poss_div_cd
             , c.spp_knd_cd
             , c.use_pnt
             , a.mm_stl_onln_seq
             , c.cc_pnt_knd_cd
             , a.stl_cycl_seq
             , coalesce(s.spp_stl_prcs_yn, 'Y') as spp_stl_prcs_yn
             , coalesce(s.hifi_slip_put_yn, 'Y') as hifi_slip_put_yn
             , to_char(v_clock_time, 'yyyymmddhh24miss') as frst_reg_dtm
             , v_usr_id as frst_reg_usr_id
             , v_pgm_id as frst_reg_pgm_id
             , to_char(v_clock_time, 'yyyymmddhh24miss') as last_mod_dtm
             , v_usr_id as last_mod_usr_id
             , v_pgm_id as last_mod_pgm_id
          from (select s.ord_no
                     , s.pymt_nos
                     , s.stl_cycl_seq
                  from base_cyclterm s         -- 튜닝변경
                 order by s.ord_no, s.pymt_nos -- 튜닝변경
                offset 0) b                    -- 튜닝변경
         inner join lateral (select s.ord_no
                                  , s.pymt_nos
                                  , s.pymt_amt_blng_yn -- 'Y':청구,'N':미청구 (default:청구)
                                  , sum(case when s.pymt_mns_cd = '1001' then coalesce(s.pymt_amt, 0) -- 포인트 결제
                                             else 0
                                         end) as point
                                  , sum(case when s.pymt_mns_cd = '1008' then coalesce(s.pymt_amt, 0) -- 특별포인트 결제
                                             else 0
                                         end) as special
                                  , sum(case when s.pymt_mns_cd = '1003' then coalesce(s.pymt_amt, 0) -- 실시간 계좌이체
                                             else 0
                                         end) as trans
                                  , sum(case when s.pymt_mns_cd = '1002' then coalesce(s.pymt_amt, 0) -- 신용카드 결제
                                             else 0
                                         end) as card
                                  , sum(case when s.pymt_mns_cd = '1006' then coalesce(s.pymt_amt, 0) -- 적립금 결제
                                             else 0
                                         end) as reserve
                                  , sum(case when s.pymt_mns_cd = '1004' then coalesce(s.pymt_amt, 0) -- 급여차감 결제
                                             else 0
                                         end) as balance
                                  , sum(case when s.pymt_mns_cd = '1007' then coalesce(s.pymt_amt, 0) -- 우리모아포인트 결제
                                             else 0
                                         end) as moa
                                  , sum(case when s.pymt_mns_cd = '1015' then coalesce(s.pymt_amt, 0) -- 코나아이포인트 결제
                                             else 0
                                         end) as kona
                                  , sum(case when s.pymt_mns_cd = '1013' then coalesce(s.pymt_amt, 0) -- 휴대폰 결제
                                             else 0
                                         end) as mpay_amt
                                  , sum(case when s.pymt_mns_cd = '1014' then coalesce(s.pymt_amt, 0) -- 할부금융 결제(에큐온결제금액)
                                             else 0
                                         end) as acuon_amt
                                  , sum(case when s.pymt_mns_cd = '9998' then coalesce(s.pymt_amt, 0) -- 기타 결제
                                             else 0
                                         end) as etc
                               from ez_ca.ca_mm_stl_ord_pymt_mns_l s
                              where s.ord_no = b.ord_no
                                and s.pymt_nos = b.pymt_nos
                              group by s.ord_no, s.pymt_nos, s.pymt_amt_blng_yn
                              order by s.ord_no, s.pymt_nos
                             offset 0) d
            on 1=1
         inner join ez_ca.ca_onln_mm_stl_b a
            on a.ord_no = b.ord_no
           and a.pymt_nos = b.pymt_nos
         inner join ez_ca.ca_spp_use_l c
            on a.ord_no = c.ord_no
           and a.user_key = c.user_key
          left outer join ez_ca.ca_stl_pnt_blng_slip_put_b s
            on c.clnt_cd = s.clnt_cd
           and c.cc_pnt_knd_cd = s.spp_knd_cd
           and c.spp_knd_cd = s.spp_grp_cd
           and s.spp_use_poss_div_cd in ('OFF', 'ALL')
         cross join max_seq m
         where c.spp_use_cncl_div_cd = 'U' -- 주문
           and (d.point + d.special + d.trans + d.card + d.reserve + d.balance + d.moa + d.kona + d.mpay_amt + d.acuon_amt + d.etc) >= 0
           and c.spp_use_poss_div_cd = 'EZP'
           and (s.spp_stl_prcs_yn is null or s.spp_stl_prcs_yn = d.pymt_amt_blng_yn);
        
        /************************************************************************
         * 06.월정산특별포인트기본 데이터 생성 (이지웰페이)
         * 
         * 특별 포인트 직결제 취소 관련
         ************************************************************************/
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'step-06, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '06.월정산특별포인트기본 데이터 생성';
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] step-06', -- 프로시저명
--            format('step-06, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), '06.월정산특별포인트기본 데이터 생성'), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
        insert into ez_ca.ca_mm_stl_spp_b (
            spp_sum_seq
            , spp_use_poss_div_cd
            , spp_knd_cd
            , spp_pymt_amt
            , mm_stl_seq
            , wsp_cd
            , stl_cycl_seq
            , spp_stl_yn
            , hifi_slip_put_obj_yn
            , frst_reg_dtm
            , frst_reg_usr_id
            , frst_reg_pgm_id
            , last_mod_dtm
            , last_mod_usr_id
            , last_mod_pgm_id
        )
        with base_cyclterm as materialized (
            select distinct
                   s1.ord_no
                 , s1.pymt_nos
                 , s3.stl_cycl_seq
              from ez_or.or_ord_gds_amt_d s1
             inner join (select s.clnt_cd
                              , s.stl_cycl_seq
                              , s.stl_strt_dt
                              , s.stl_end_dt
                           from ez_ca.ca_clnt_stl_cycl_term_b s
                          where s.cnfm_yn = 'N'
                            and s.stl_onln_ofln_div_cd = '01'
                            and s.stl_strt_dt <= v_prev01_dd_dt
                            and s.stl_ym >= v_dfns_ym -- TODO 방어로직
                            and s.clnt_cd = any(v_clntcd_arr)
                            and s.stl_strt_dt >= v_min_stl_strt_dt) s3
                on s1.clnt_stl_prcs_strt_dtm between s3.stl_strt_dt || '000000' and s3.stl_end_dt || '235959'
               and s1.clnt_cd = s3.clnt_cd
        ), max_seq as (
            select coalesce(max(spp_sum_seq), 1) as max_seq
              from ez_ca.ca_mm_stl_spp_b
        )
        select m.max_seq + row_number() over() as spp_sum_seq
             , c.spp_use_poss_div_cd
             , c.spp_knd_cd
             , c.use_pnt
             , a.mm_stl_onln_seq
             , c.cc_pnt_knd_cd
             , a.stl_cycl_seq
             , coalesce(s.spp_stl_prcs_yn, 'Y') as spp_stl_prcs_yn
             , coalesce(s.hifi_slip_put_yn, 'Y') as hifi_slip_put_yn
             , to_char(v_clock_time, 'yyyymmddhh24miss') as frst_reg_dtm
             , v_usr_id as frst_reg_usr_id
             , v_pgm_id as frst_reg_pgm_id
             , to_char(v_clock_time, 'yyyymmddhh24miss') as last_mod_dtm
             , v_usr_id as last_mod_usr_id
             , v_pgm_id as last_mod_pgm_id
          from (select s.ord_no
                     , s.pymt_nos
                     , s.stl_cycl_seq
                  from base_cyclterm s         -- 튜닝변경
                 order by s.ord_no, s.pymt_nos -- 튜닝변경
                offset 0) b                    -- 튜닝변경
         inner join lateral (select s.ord_no
                                  , s.pymt_nos
                                  , s.pymt_amt_blng_yn -- 'Y':청구,'N':미청구 (default:청구)
                                  , sum(case when s.pymt_mns_cd = '1001' then coalesce(s.pymt_amt, 0) -- 포인트 결제
                                             else 0
                                         end) as point
                                  , sum(case when s.pymt_mns_cd = '1008' then coalesce(s.pymt_amt, 0) -- 특별포인트 결제
                                             else 0
                                         end) as special
                                  , sum(case when s.pymt_mns_cd = '1003' then coalesce(s.pymt_amt, 0) -- 실시간 계좌이체
                                             else 0
                                         end) as trans
                                  , sum(case when s.pymt_mns_cd = '1002' then coalesce(s.pymt_amt, 0) -- 신용카드 결제
                                             else 0
                                         end) as card
                                  , sum(case when s.pymt_mns_cd = '1006' then coalesce(s.pymt_amt, 0) -- 적립금 결제
                                             else 0
                                         end) as reserve
                                  , sum(case when s.pymt_mns_cd = '1004' then coalesce(s.pymt_amt, 0) -- 급여차감 결제
                                             else 0
                                         end) as balance
                                  , sum(case when s.pymt_mns_cd = '1007' then coalesce(s.pymt_amt, 0) -- 우리모아포인트 결제
                                             else 0
                                         end) as moa
                                  , sum(case when s.pymt_mns_cd = '1015' then coalesce(s.pymt_amt, 0) -- 코나아이포인트 결제
                                             else 0
                                         end) as kona
                                  , sum(case when s.pymt_mns_cd = '1013' then coalesce(s.pymt_amt, 0) -- 휴대폰 결제
                                             else 0
                                         end) as mpay_amt
                                  , sum(case when s.pymt_mns_cd = '1014' then coalesce(s.pymt_amt, 0) -- 할부금융 결제(에큐온결제금액)
                                             else 0
                                         end) as acuon_amt
                                  , sum(case when s.pymt_mns_cd = '9998' then coalesce(s.pymt_amt, 0) -- 기타 결제
                                             else 0
                                         end) as etc
                               from ez_ca.ca_mm_stl_ord_pymt_mns_l s
                              where s.ord_no = b.ord_no
                                and s.pymt_nos = b.pymt_nos
                              group by s.ord_no, s.pymt_nos, s.pymt_amt_blng_yn
                              order by s.ord_no, s.pymt_nos
                             offset 0) d
            on 1=1
         inner join ez_ca.ca_onln_mm_stl_b a
            on a.ord_no = b.ord_no
           and a.pymt_nos = b.pymt_nos
         inner join ez_ca.ca_spp_use_l c
            on a.ord_no = c.ord_no
           and a.user_key = c.user_key
          left outer join ez_ca.ca_stl_pnt_blng_slip_put_b s
            on c.clnt_cd = s.clnt_cd
           and c.cc_pnt_knd_cd = s.spp_knd_cd
           and c.spp_knd_cd = s.spp_grp_cd
           and s.spp_use_poss_div_cd in ('OFF', 'ALL')
         cross join max_seq m
         where c.spp_use_cncl_div_cd = 'C' -- 취소
           and (d.point + d.special + d.trans + d.card + d.reserve + d.balance + d.moa + d.kona + d.mpay_amt + d.acuon_amt + d.etc) < 0
           and c.spp_use_poss_div_cd = 'EZP'
           and (s.spp_stl_prcs_yn is null or s.spp_stl_prcs_yn = d.pymt_amt_blng_yn);
        
        o_result := 'OK';
        
        select clock_timestamp()
          into v_clock_time;
        
        raise notice 'sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure End, 실행일시[%], 내용[%]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), o_result;
        
--        call ez_ca.sp_stl_pgm_exec_prcs_log_bat(
--            v_pk, -- 처리로그키값(넘어온값)
--            'ez_ca.sp_bsicinfordloan_dd_bat_onln_spp_pnt', -- 프로시저ID
--            '[고객사정산(온라인특별포인트) 이관 일배치] sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure End', -- 프로시저명
--            format('sp_bsicinfordloan_dd_bat_onln_spp_pnt Procedure End, 실행일시[%s], 내용[%s]', to_char(v_clock_time, 'yyyy-mm-dd hh24:mi:ss'), o_result), -- 프로시저정상처리내용
--            v_pgm_id, -- 메인배치ID
--            v_pk -- 처리로그키값(채번키값)
--        );
        
    exception when others then
        declare
            v_detail text;
            v_msg text;
        begin
            get stacked diagnostics
            v_detail = pg_exception_detail;
            v_msg := left(
                format(
                    '[%s] %s | %s',
                    sqlstate,
                    sqlerrm,
                    coalesce(v_detail, '-')
                ),
                2000
            );
            raise exception using
            errcode = sqlstate,
            message = v_msg;
            raise notice '[%] [%]', errcode, v_detail;
            o_result := v_msg;
        end;
    end;
$procedure$