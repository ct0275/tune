create index concurrently if not exists cl_clm_b_ix10
    on ez_or.cl_clm_b (clm_knd_cd, clm_cmpt_dtm, ord_no);
	
--DROP INDEX CONCURRENTLY IF EXISTS ez_or.cl_clm_b_ix10;

analyze ez_or.cl_clm_b;

CREATE INDEX CONCURRENTLY IF NOT EXISTS dl_dlv_b_ix15
ON ez_or.dl_dlv_b (ord_no)
WHERE dlv_st_cd = 'STBY'
  AND dlv_obnd_typ_cd <> 'WTWD';
  
DROP INDEX CONCURRENTLY IF EXISTS ez_or.dl_dlv_b_ix15;

/* com.ezwelesp.ex.order.rest.hpas.mapper.query.HpasOrderListQueryMapper.selectOrderList */
/* 주문목록 조회 */
WITH oob AS MATERIALIZED
(
    SELECT
           oob.*
      FROM ez_or.or_ord_b oob
     WHERE 1 = 1
       /* 주문상태 */
       AND oob.ord_st_cd NOT IN ('WAIT', 'FAIL')
       /* ============================================================
        * [동적 검색조건 영역]
        * MyBatis 등에서 기존처럼 oob 기준으로 조건 추가
        *
        * 예)
        * AND oob.ord_no = #{ordNo}
        * AND oob.user_key = #{userKey}
        * AND oob.ord_dtm >= #{ordDtmFrom}
        * AND oob.ord_dtm <= #{ordDtmTo}
        * ============================================================ */
       /* 취소완료 기간 조건 */
       AND EXISTS
       (
           SELECT 1
             FROM ez_or.cl_clm_b ccb
            WHERE ccb.ord_no = oob.ord_no
              AND ccb.clm_knd_cd = 'CNCL'
              AND ccb.clm_cmpt_dtm >= '20260501000000'
              AND ccb.clm_cmpt_dtm <= '20260731235959'
       )
)
SELECT
       oob.ord_no
     , oob.asp_ord_no
     , oob.ordr_nm
     , oob.ordr_telno
     , oob.ordr_mbl_telno
     , oob.pcc
     , oob.ord_dtm
     , oob.ord_st_cd
     , oob.acss_dvc_cd
     , oob.ord_typ_cd
     /* 배송지정보 */
     , ddab.dlv_adr_no
     , dlvexp.dlv_exp
     , dlvexp.ismt_add_dlv_exp
     , dlvexp.arpay_rmtt_dlv_exp
     , dlvexp.jeju_add_dlv_exp
     , ddab.rcvr_nm
     , ddab.rcvr_telno
     , ddab.rcvr_mbl_telno
     , ddab.rcvr_zipcd
     , ddab.rcvr_bas_adr
     , ddab.rcvr_dtl_adr
     , ddab.dlv_req_cntn
     /* 선물하기 정보 */
     , gift.gvgft_ord_st_cd
     , gift.prsn_msg_cntn
     /* 화면 기준 선물메세지 발송시간 = 주문일시 */
     , CASE
           WHEN gift.prsn_msg_cntn IS NOT NULL
           THEN oob.ord_dtm
       END AS prsn_msg_snd_dtm
     /* 배송정보 */
     , ddb.dlv_no
     , ddb.csp_cd
     , ddb.csp_obnd_loc_no
     , ddb.invc_no
     , ddb.dlv_co_cd
     , ddb.dlv_st_cd
     , ddb.dlv_strt_dtm
     , ddb.dlv_cmpt_dtm
     /* 상품정보 */
     , oogd.ord_gds_seq
     , oogd.orgl_ord_gds_seq
     , oogd.frst_ord_gds_seq
     , ddgd.dlv_gds_seq
     , oogd.gds_cd
     , oogd.gds_nm
     , ddgd.dlv_gds_qty
     , ddgd.dlv_gds_st_cd
     , ddgd.dlv_cncl_dtm
     , oogd.opt_gds_comb_seq
     , REPLACE(
           oogd.ord_gds_opt_cntn
         , ';'
         , ':'
       ) AS ord_gds_opt_cntn
     , oogd.csp_gds_cd
     , CASE
           WHEN cstb.txaf_evdn_knd_cd = 'T'
            AND cstb.cms_stl_inf_use_yn = 'Y'
            AND COALESCE(
                    oogd.csp_cms_knd_cd
                  , csp.csp_cms_knd_cd
                ) = '01'
           THEN NULL
           ELSE oogd.ord_gds_pchs_prc
       END AS pchs_prc
     , CASE
           WHEN cstb.txaf_evdn_knd_cd = 'T'
            AND cstb.cms_stl_inf_use_yn = 'Y'
            AND COALESCE(
                    oogd.csp_cms_knd_cd
                  , csp.csp_cms_knd_cd
                ) = '01'
           THEN COALESCE(oogd.csp_gds_cms_rt, 0)
           ELSE COALESCE(oogd.ord_gds_cms_rt, 0)
       END AS ord_gds_cms_rt
     , oogd.ord_gds_sell_prc AS sell_prc
     , oogd.opt_sell_prc
     , cpn.cpn_use_amt AS dc_amt
     , oogd.nrml_sell_prc
     , oogd.ord_gds_qty
     , clm.tot_cncl_qty
     , clm.cncl_qty
     , clm.rtp_cncl_qty
     , clm.ostk_cncl_qty
     , ddb.dlv_obnd_typ_cd
     , clm.clm_exch_gds_qty
  FROM oob
       /* ============================================================
        * 배송기본
        * ============================================================ */
       INNER JOIN LATERAL
       (
           SELECT ddb.*
             FROM ez_or.dl_dlv_b ddb
            WHERE ddb.ord_no = oob.ord_no
              AND ddb.dlv_obnd_typ_cd NOT IN ('WTWD')
              AND ddb.dlv_st_cd = 'STBY'
            OFFSET 0
       ) ddb
       ON TRUE
       /* 배송주소 */
       INNER JOIN ez_or.dl_dlv_adr_b ddab
          ON ddab.ord_no = ddb.ord_no
         AND ddab.dlv_adr_no = ddb.dlv_adr_no
       /* 사용자 */
       INNER JOIN LATERAL
       (
           SELECT
                  usr.usr_nm
                , usr.test_usr_yn
             FROM ez_ct.vw_ct_usr_b usr
            WHERE usr.user_key = oob.user_key
              AND usr.test_usr_yn = 'N'
            OFFSET 0
       ) usr
       ON TRUE
       /* 배송비 */
       LEFT JOIN LATERAL
       (
           SELECT
                  SUM(exp.dlv_exp)          AS dlv_exp
                , SUM(exp.ismt_add_dlv_exp) AS ismt_add_dlv_exp
                , SUM(exp.arpay_rmtt_dlv_exp) AS arpay_rmtt_dlv_exp
                , SUM(exp.jeju_add_dlv_exp) AS jeju_add_dlv_exp
                , dlv.ord_no
                , dlv.dlv_adr_no
             FROM ez_or.dl_dlv_b dlv
                  INNER JOIN ez_or.dl_dlv_exp_b exp
                     ON exp.dlv_exp_no = dlv.dlv_exp_no
            WHERE dlv.ord_no = oob.ord_no
              AND dlv.csp_cd = '10091950'
              AND dlv.dlv_obnd_typ_cd = 'ORD'
              AND dlv.divd_dlv_yn = 'N'
            GROUP BY
                  dlv.dlv_adr_no
                , dlv.ord_no
            OFFSET 0
       ) dlvexp
       ON dlvexp.dlv_adr_no = ddab.dlv_adr_no
      AND dlvexp.ord_no = ddab.ord_no
       /* 배송상품 */
       INNER JOIN LATERAL
       (
           SELECT ddgd.*
             FROM ez_or.dl_dlv_gds_d ddgd
            WHERE ddgd.dlv_no = ddb.dlv_no
              AND ddgd.ord_no = oob.ord_no
              AND ddgd.dlv_gds_qty > 0
            OFFSET 0
       ) ddgd
       ON TRUE
       /* 주문상품 */
       INNER JOIN LATERAL
       (
           SELECT oogd.*
             FROM ez_or.or_ord_gds_d oogd
            WHERE oogd.ord_no = oob.ord_no
              AND oogd.ord_gds_seq = ddgd.ord_gds_seq
              AND oogd.cncl_gds_qty > 0
            OFFSET 0
       ) oogd
       ON TRUE
       /* 협력사 */
       INNER JOIN ez_co.co_csp_b csp
          ON csp.csp_cd = oogd.csp_cd
       /* ============================================================
        * 쿠폰
        * ============================================================ */
       LEFT JOIN LATERAL
       (
           SELECT
                  ordcpn.ord_no
                , ordcpn.ord_gds_seq
                , SUM(ordcpn.cpn_use_amt) AS cpn_use_amt
             FROM
             (
                 /* 주문쿠폰 */
                 SELECT
                        SUM(oocd.cpn_use_amt) AS cpn_use_amt
                      , oocd.ord_no
                      , oocd.ord_gds_seq
                   FROM ez_or.or_ord_cpn_d oocd
                  WHERE oocd.ord_gds_seq IS NOT NULL
                    AND oocd.cpn_use_cncl_yn = 'N'
                    AND oocd.clm_no IS NULL
                    AND oocd.ord_no = oob.ord_no
                  GROUP BY
                        oocd.ord_no
                      , oocd.ord_gds_seq
                 UNION ALL
                 /* 상품쿠폰 */
                 SELECT
                        SUM(oocgd.cpn_use_amt) AS cpn_use_amt
                      , oocgd.ord_no
                      , oocgd.ord_gds_seq
                   FROM ez_or.or_ord_cpn_gds_d oocgd
                        INNER JOIN ez_or.or_ord_cpn_d ooc
                           ON ooc.ord_cpn_no = oocgd.ord_cpn_no
                          AND ooc.cpn_use_cncl_yn = 'N'
                  WHERE oocgd.ord_no = oob.ord_no
                  GROUP BY
                        oocgd.ord_no
                      , oocgd.ord_gds_seq
             ) ordcpn
            GROUP BY
                  ordcpn.ord_no
                , ordcpn.ord_gds_seq
            OFFSET 0
       ) cpn
       ON cpn.ord_no = oob.ord_no
      AND cpn.ord_gds_seq = oogd.ord_gds_seq
       /* ============================================================
        * 클레임 수량
        * ============================================================ */
       LEFT JOIN LATERAL
       (
           SELECT
                  ccgd.ord_no
                , ccgd.ord_gds_seq
                , ccgd.dlv_no
                , ccgd.dlv_gds_seq
                , SUM(
                      CASE
                          WHEN ccb.clm_knd_cd IN ('CNCL', 'AMTC', 'RTP')
                          THEN ccgd.clm_gds_qty - ccgd.cncl_qty
                          ELSE 0
                      END
                  ) AS tot_cncl_qty
                , SUM(
                      CASE
                          WHEN ccb.clm_knd_cd IN ('CNCL', 'AMTC')
                           AND ccrl.clm_rsn_cd <> '1005'
                          THEN ccgd.clm_gds_qty - ccgd.cncl_qty
                          ELSE 0
                      END
                  ) AS cncl_qty
                , SUM(
                      CASE
                          WHEN ccb.clm_knd_cd = 'RTP'
                          THEN ccgd.clm_gds_qty - ccgd.cncl_qty
                          ELSE 0
                      END
                  ) AS rtp_cncl_qty
                , SUM(
                      CASE
                          WHEN ccb.clm_knd_cd IN ('CNCL', 'AMTC')
                           AND ccrl.clm_rsn_cd = '1005'
                          THEN ccgd.clm_gds_qty - ccgd.cncl_qty
                          ELSE 0
                      END
                  ) AS ostk_cncl_qty
                , SUM(
                      CASE
                          WHEN ccb.clm_knd_cd = 'EXCH'
                          THEN ccgd.clm_gds_qty - ccgd.cncl_qty
                          ELSE 0
                      END
                  ) AS clm_exch_gds_qty
             FROM ez_or.cl_clm_b ccb
                  INNER JOIN ez_or.cl_clm_gds_d ccgd
                     ON ccgd.clm_no = ccb.clm_no
                  INNER JOIN ez_or.cl_clm_rsn_l ccrl
                     ON ccrl.clm_no = ccgd.clm_no
                    AND ccrl.clm_gds_seq = ccgd.clm_gds_seq
            WHERE ccb.ord_no = oogd.ord_no
              AND ccgd.ord_gds_seq = oogd.ord_gds_seq
              AND ccgd.dlv_no = ddb.dlv_no
              AND ccgd.dlv_gds_seq = ddgd.dlv_gds_seq
              AND ccb.clm_st_cd NOT IN ('WTDR')
            GROUP BY
                  ccgd.ord_no
                , ccgd.ord_gds_seq
                , ccgd.dlv_no
                , ccgd.dlv_gds_seq
            OFFSET 0
       ) clm
       ON TRUE
       /* 선물하기 */
       LEFT JOIN ez_or.or_gvgft_ord_b gift
         ON gift.ord_no = oob.ord_no
       /* 정산템플릿 */
       LEFT JOIN ez_co.co_stl_tmpl_b cstb
         ON cstb.stl_tmpl_seq = oogd.stl_tmpl_seq
 WHERE 1 = 1
   /* 협력사 조건 */
   AND (
           oogd.csp_cd = '10091950'
           OR oob.ord_dtm IS NULL
       )
   /* 배송 협력사 조건 */
   AND (
           ddb.csp_cd = '10091950'
           OR oob.ord_dtm IS NULL
       )
   /* 배송상태 */
   AND ddb.dlv_st_cd <> 'INSR_STBY'
   /* 취소수수료/교환상품 제외 */
   AND oogd.orgl_ord_gds_seq IS NULL
   /* 취소수수료 발생상품 제외 */
   AND oogd.cncl_cms_ocrn_gds_yn = 'N'
   /* 금액변경상품 제외 */
   AND oogd.amt_chg_gds_yn = 'N'
   /* 배송출고유형 */
   AND (
           ddb.dlv_obnd_typ_cd IN ('ORD')
           OR (
                  ddb.dlv_obnd_typ_cd = 'EXCH'
                  AND (
                         ddb.dlv_st_cd NOT IN ('CNCL')
                         OR ddb.dlv_st_cd IS NULL
                      )
              )
       )
 ORDER BY
       oob.ord_no
     , ddab.dlv_adr_no
     , ddb.dlv_no
     , oogd.ord_gds_seq
;