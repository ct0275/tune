WITH coupon AS MATERIALIZED (
    SELECT ord_no
      FROM ez_or.or_bcd_cpn_b
     WHERE bcd_no = '2222275835298598'
),
prd_102 AS MATERIALIZED (
    SELECT 1
      FROM coupon c
      JOIN ez_or.or_ord_gds_d oogd
        ON oogd.ord_no = c.ord_no
     WHERE oogd.ch_cd = '102'
       AND oogd.csp_cd = '10031113'
     LIMIT 1
),
prd_103 AS (
    SELECT 1
      FROM ez_or.dl_ord_snd_gds_d
     WHERE intg_gds_rdno_no = '2222275835298598'
       AND csp_cd = '10031113'
     LIMIT 1
)
SELECT CASE
         WHEN EXISTS (SELECT 1 FROM prd_103) THEN '103'
         WHEN EXISTS (SELECT 1 FROM prd_102) THEN '102'
         ELSE '103'
       END AS intg_prd_typ;