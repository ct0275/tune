/* com.ezwelesp.bo.hcas.customer.rest.point.mapper.query.HcasPointAssignListQueryMapper.selectPointAssignList */
WITH target_cwab AS
(
    SELECT
          cwab.wsp_asg_wrk_no
        , cwab.clnt_cd
        , cwab.user_key
        , cwab.wsp_asg_no
        , cwab.wsp_div_cd
        , cwab.wsp_cd
        , cwab.wsp_typ_cd
        , cwab.wsp_amt
        , cwab.wsp_asg_st_cd
        , cwab.frst_reg_dtm
    FROM ez_ct.cp_wsp_asg_b cwab
    JOIN ez_ct.vw_ct_usr_b cuba
      ON cuba.clnt_cd = cwab.clnt_cd
     AND cuba.user_key = cwab.user_key
     AND cuba.test_usr_yn = 'N'
     AND cuba.clnt_cd = 'kcomwel'
     AND cuba.usr_nm LIKE '유은샘%'
     AND cuba.cc_br_cd IN ('1007', '1100')
     AND cuba.cc_team_cd IN ('1031')
    WHERE cwab.clnt_cd = 'kcomwel'
      AND cwab.wsp_asg_st_cd = 'COMP'
      AND cwab.frst_reg_dtm BETWEEN '20260101' AND '20260911235959'
),
target_wrk AS
(
    SELECT
        cwaw.wsp_asg_wrk_no
    FROM ez_ct.cp_wsp_asg_wrk_b cwaw
    JOIN target_cwab cwab
      ON cwab.wsp_asg_wrk_no = cwaw.wsp_asg_wrk_no
    WHERE cwaw.clnt_cd = 'kcomwel'
    GROUP BY cwaw.wsp_asg_wrk_no
    ORDER BY cwaw.wsp_asg_wrk_no DESC NULLS LAST
    LIMIT 10
)
SELECT
      cwaw.wsp_asg_wrk_no
    , cwaw.clnt_cd
    , cwaw.wsp_asg_wrk_typ_cd
    , ccdc.comm_dtl_cd_nm AS wsp_asg_wrk_typ_nm
    , cwaw.frst_reg_usr_id
    , cwaw.frst_reg_usr_id AS frst_reg_usr_id
    , to_char(
          to_timestamp(cwaw.frst_reg_dtm, 'YYYYMMDDHH24MISS'),
          'YYYY-MM-DD HH24:MI:SS'
      ) AS frst_reg_dtm
    , count(cwab.user_key) AS assign_personnel
    , max(cwab.wsp_amt) AS assign_max_amt
    , coalesce(
        sum(
            CASE
                WHEN cwab.wsp_div_cd = '1000'
                 AND cwab.wsp_typ_cd = 'I'
                THEN pnt.wsp_amt
                ELSE 0
            END
        ), 0
      ) AS welfare_point_total
    , coalesce(
        sum(
            CASE
                WHEN cwab.wsp_div_cd = '2000'
                 AND cwab.wsp_typ_cd = 'I'
                THEN pnt.wsp_amt
                ELSE 0
            END
        ), 0
      ) AS special_point_total
    , coalesce(
        sum(
            CASE
                WHEN cwab.wsp_div_cd = '1000'
                 AND cwab.wsp_typ_cd = 'U'
                THEN pnt.wsp_amt
                ELSE 0
            END
        ), 0
      ) AS welfare_point_use
    , coalesce(
        sum(
            CASE
                WHEN cwab.wsp_div_cd = '2000'
                 AND cwab.wsp_typ_cd = 'U'
                THEN pnt.wsp_amt
                ELSE 0
            END
        ), 0
      ) AS special_point_use
    , coalesce(
          d.sys_knd_cd,
          cwaw.frst_reg_pgm_id
      ) AS frst_reg_pgm_id
    , CASE
        WHEN d.mgr_nm IS NOT NULL
        THEN concat(d.mgr_nm, '(', d.mgr_lgin_id, ')')
        ELSE cwaw.frst_reg_usr_id
      END AS usr_nm
FROM target_wrk tw
JOIN ez_ct.cp_wsp_asg_wrk_b cwaw
  ON cwaw.wsp_asg_wrk_no = tw.wsp_asg_wrk_no
 AND cwaw.clnt_cd = 'kcomwel'
JOIN target_cwab cwab
  ON cwab.wsp_asg_wrk_no = cwaw.wsp_asg_wrk_no
JOIN LATERAL
(
    SELECT cuwb.wsp_amt
    FROM ez_ct.cp_usr_wfp_b cuwb
    WHERE cwab.clnt_cd = cuwb.clnt_cd
      AND cwab.user_key = cuwb.user_key
      AND cwab.wsp_asg_no = cuwb.wsp_asg_no
      AND cwab.wsp_div_cd = '1000'
      AND cwab.wsp_cd = cuwb.wfp_wsp_cd
    UNION ALL
    SELECT
        CASE
            WHEN cwab.wsp_typ_cd = 'U'
            THEN csb.rmn_pnt
            ELSE csb.asg_wsp_amt
        END AS wsp_amt
    FROM ez_ct.cp_spp_b csb
    WHERE cwab.clnt_cd = csb.clnt_cd
      AND cwab.user_key = csb.user_key
      AND cwab.wsp_cd = csb.spp_wsp_cd
      AND cwab.wsp_asg_no = csb.wsp_asg_no
) pnt
  ON true
LEFT JOIN ez_cm.cm_comm_dtl_c ccdc
  ON cwaw.wsp_asg_wrk_typ_cd = ccdc.comm_dtl_cd
 AND ccdc.comm_cd = 'wsp_asg_wrk_typ_cd'
LEFT JOIN ez_cm.cm_mgr_b d
  ON d.mgr_id = cwaw.frst_reg_usr_id
GROUP BY
      cwaw.wsp_asg_wrk_no
    , cwaw.clnt_cd
    , cwaw.wsp_asg_wrk_typ_cd
    , cwaw.frst_reg_dtm
    , ccdc.comm_dtl_cd_nm
    , cwaw.frst_reg_pgm_id
    , cwaw.frst_reg_usr_id
    , d.mgr_nm
    , d.mgr_lgin_id
    , d.sys_knd_cd
ORDER BY
    cwaw.wsp_asg_wrk_no DESC NULLS LAST
LIMIT 10;