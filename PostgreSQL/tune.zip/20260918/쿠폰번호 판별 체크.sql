/* com.ezwelesp.ex.product.rest.hpas.ecoupon.mapper.query.EcouponCommQueryMapper.selectBarcodePrdTypChk */
select coalesce(max(re.intg_prd_typ),'103') intg_prd_typ from
(
select '102' intg_prd_typ
from ez_or.or_bcd_cpn_b obcb
inner join ez_or.or_ord_gds_d oogd
on obcb.ord_no = oogd.ord_no
and oogd.ch_cd = '102'
where obcb.bcd_no = '2222275835298598'
and oogd.csp_cd = '10031113'
union all
select '103' intg_prd_typ
from ez_or.dl_ord_snd_gds_d
where intg_gds_rdno_no = '2222275835298598'
and csp_cd = '10031113'
) re
group by re.intg_prd_typ