--9,235

/* com.ezwelesp.bo.hcas.customer.rest.point.mapper.query.HcasPointAssignListQueryMapper.selectPointAssignList */
select /* [포인트 내역조회] HcasPointAssignListQueryMapper.selectPointAssignList */ 
			cwaw.wsp_asg_wrk_no 
			, cwaw.clnt_cd 
			, cwaw.wsp_asg_wrk_typ_cd
			, ccdc.comm_dtl_cd_nm as wsp_asg_wrk_typ_nm 
			, cwaw.frst_reg_usr_id
			, cwaw.frst_reg_usr_id as frst_reg_usr_id
			, to_char(to_timestamp(cwaw.frst_reg_dtm, 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD HH24:MI:SS') frst_reg_dtm
			, count(cwab.user_key) as assign_personnel
			, max(cwab.wsp_amt) as assign_max_amt
			, coalesce(sum(case when cwab.wsp_div_cd = '1000' and  cwab.wsp_typ_cd = 'I' then pnt.wsp_amt else 0 end ) ,0) as welfare_point_total
			, coalesce(sum(case when cwab.wsp_div_cd = '2000' and  cwab.wsp_typ_cd = 'I' then pnt.wsp_amt else 0 end ) ,0) as special_point_total
			, coalesce(sum(case when cwab.wsp_div_cd = '1000' and  cwab.wsp_typ_cd = 'U' then pnt.wsp_amt else 0 end ) ,0) as welfare_point_use
			, coalesce(sum(case when cwab.wsp_div_cd = '2000' and  cwab.wsp_typ_cd = 'U' then pnt.wsp_amt else 0 end ) ,0) as special_point_use
			, coalesce(d.sys_knd_cd,cwaw.frst_reg_pgm_id) as frst_reg_pgm_id 
			, case when d.mgr_nm is not null then  concat(d.mgr_nm, '(', d.mgr_lgin_id, ')') 
				else cwaw.frst_reg_usr_id end as usr_nm
		from ez_ct.cp_wsp_asg_wrk_b cwaw
		inner join ez_ct.cp_wsp_asg_b cwab
		   on /* cwaw.clnt_cd = cwab.clnt_cd and -- 잘못된 인덱스 타므로 막음. */
		      cwaw.wsp_asg_wrk_no = cwab.wsp_asg_wrk_no 
		join lateral 
            (
                select cuwb.wsp_amt
                from ez_ct.cp_usr_wfp_b cuwb
                where cwab.clnt_cd = cuwb.clnt_cd
                    and cwab.user_key = cuwb.user_key 
                    and cwab.wsp_asg_no = cuwb.wsp_asg_no
                    and cwab.wsp_div_cd = '1000'     
                    and cwab.wsp_cd = cuwb.wfp_wsp_cd    
                union all
                select  /*2026.03.10 특복 U일 경우 배정금액=0, 잔여금액만 마이너스 이므로 잔여금액을 조회해서 보여준다. */
                        /* csb.asg_wsp_amt as wsp_amt */
                        case when cwab.wsp_typ_cd = 'U' then csb.rmn_pnt else csb.asg_wsp_amt end as wsp_amt
                from ez_ct.cp_spp_b csb
                where   cwab.clnt_cd = csb.clnt_cd 
                    and cwab.user_key = csb.user_key 
                    and cwab.wsp_cd = csb.spp_wsp_cd    
                    and cwab.wsp_asg_no = csb.wsp_asg_no  
                 offset 0
            ) pnt  
                on     1=1
		join lateral (select st.cc_br_cd                           
                     , st.cc_dept_cd                      
                     , st.cc_team_cd               
                     , st.cc_part_cd            
                     , st.usr_nm  
                     , st.self_crtf_bymd_dt  
                     , st.self_crtf_gndr_nval  
                     , st.user_key  
                     , st.clnt_empno  
                  from ez_ct.vw_ct_usr_b st               
                 where st.clnt_cd = cwab.clnt_cd
                   and st.user_key = cwab.user_key  
                   and st.clnt_cd = 'kcomwel' 
                   and st.test_usr_yn = 'N'
                offset 0) cuba                              
	        on 1=1     
		left outer join ez_cm.cm_comm_dtl_c ccdc
			on cwaw.wsp_asg_wrk_typ_cd = ccdc.comm_dtl_cd
			and ccdc.comm_cd = 'wsp_asg_wrk_typ_cd'
		left join ez_cm.cm_mgr_b d 
			on d.mgr_id = cwaw.frst_reg_usr_id	
		where cwaw.clnt_cd = 'kcomwel' 
		    -- 2026.02.27 hims에서 과배정승인 시 작업기본 상태를 APRV로 update하지 않으므로 제외
			--and wsp_asg_wrk_prcs_st_cd = 'APRV'
			and cwab.wsp_asg_st_cd = 'COMP' 	             
	            	 and cwab.frst_reg_dtm between '20260101' and concat('20260911','235959')	             
	                    and cuba.usr_nm like '유은샘' || '%'
	                    and cuba.usr_nm like '유은샘' || '%'
			        and cuba.cc_br_cd in 
			             (  
			                '1007'
			             , 
			                '1100'
			             ) 
			        and cuba.cc_team_cd in 
			             (  
			                '1031'
			             , 
			                '1031'
			             ) 
			group by cwaw.wsp_asg_wrk_no, cwaw.clnt_cd , ccdc.comm_dtl_cd_nm , cwaw.frst_reg_pgm_id , cwaw.frst_reg_usr_id, d.mgr_nm, d.mgr_lgin_id, d.sys_knd_cd
		 	order by cwaw.wsp_asg_wrk_no desc nulls last LIMIT 10