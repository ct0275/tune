/* com.ezwelesp.bo.hims.order.rest.order.mapper.query.OrderQueryMapper.getOrderListByGoods */
SELECT 
    schemaname AS 스키마명,
    tablename AS 테이블명,
    indexname AS 인덱스명,
    indexdef AS 인덱스생성구문
FROM 
    pg_indexes
WHERE 
    schemaname = 'ez_or'           -- 찾고자 하는 스키마명
    AND tablename = 'or_ord_b';    -- 찾고자 하는 테이블명
    
    select * from ez_or.dl_dlv_b

select count(*) from (
  select distinct ccb.ord_no from ez_or.cl_clm_b ccb
   where ccb.clm_knd_cd='CNCL'
     and ccb.clm_cmpt_dtm between '20260503000000' and '20260513235959'
) c
where exists (select 1 from ez_or.or_ord_gds_d g
               where g.ord_no=c.ord_no and g.csp_cd='10090248');
    
select * from ez_pd.pd_gds_c pgc 
where gds_sell_st_cd = '1002' /*상품판매상태코드*/
--and gds_typ_dtl_cd in ('1022', '2001', '2002') /*지류상품권, 모바일 상품권, 모바일 e쿠폰*/ /*'2003' , 모바일 이용권*/
and cshab_gds_typ_cd = 'NG'  /*유가증권*/
--and ch_cd = '103'
and self_crtf_need_yn = 'N'

select  cub.self_crtf_excp_allw_dt, cub.self_Crtf_Yn, cub.* 
from ez_ct.ct_usr_b cub 
--join ez_ct.ct_usr_d cud on cud.user_key = cub.user_key 
where cub.clnt_cd = 'hez'
order by cub.frst_reg_dtm desc

select * from ez_cm.cm_ch_b ccb 
    
/* 주문목록 조회 */
/*explain(ANALYZE, BUFFERS) 
		with oob as ( --materialized (
			         select distinct on (oob.ord_no) oob.* 
		               from ez_or.or_ord_b oob
		               join ez_or.or_ord_gds_d oogd on oogd.ord_no = oob.ord_no and oogd.csp_cd = '10091950'
		              where exists (
										select distinct on (ccb.ord_no) ccb.ord_no 
										from ez_or.cl_clm_b ccb
										inner join ez_or.cl_clm_gds_d ccgd
                                       		on ccgd.clm_no = ccb.clm_no 
                                       		and ccgd.clm_gds_seq = oogd.ord_gds_seq
                                       	inner join ez_or.or_ord_gds_d oogd
                                       		on oogd.ord_no = ccgd.ord_no
                                       		and oogd.ord_gds_seq = ccgd.ord_gds_seq
                                       		and oogd.csp_cd = '10091950'					                  		 
										where ccb.ord_no = oob.ord_no
										and ccb.clm_cmpt_dtm  >=  '20260503' || '000000'
										and ccb.clm_cmpt_dtm  <=  '20260813' || '235959'
										and ccb.clm_knd_cd = 'CNCL'
								)and ord_st_cd not in ('WAIT', 'FAIL') /* 주문대기, 주문실패 건 제외 */					
			        )
*/
              
--------원래 쿼리
              
       with oob as (
         select oob.* 
           from ez_or.or_ord_b oob
          where 1=1
            and ord_st_cd not in ('WAIT', 'FAIL') /* 주문대기, 주문실패 건 제외 */
                    and exists (
                            select 1 
                            from ez_or.cl_clm_b ccb
                            where ccb.clm_knd_cd = 'CNCL'
                            and ccb.ord_no = oob.ord_no
                            and ccb.clm_cmpt_dtm  >=  '20260601' || '000000'
                            and ccb.clm_cmpt_dtm  <=  '20260831' || '235959'
                    )
        )

--------튜닝 쿼리     

/* com.ezwelesp.bo.hims.order.rest.order.mapper.query.OrderQueryMapper.getOrderListByGoods */
        /*+ leading((oob ogd)) nestloop(ogd oob) */
        select *
        from (
            select temp.user_key
                , temp.ord_no
                , temp.ord_gds_seq
                , temp.ord_st_cd
                , case when temp.ord_dlv_knd_cd = 'DLV' then
                			case cddlvst.comm_dtl_cd when 'INSR_STBY' then '주문완료'
                									 when 'STBY' then '주문완료'
                									 when 'RDY' then '상품준비중'
                									 when 'OBND' then '출고진행'
                									 when 'DLV' then '배송중'
                									 when 'CMPT' then '배송완료'
                									 when 'CNCL' then '주문취소'
                			                         else cdordst.comm_dtl_cd_nm  
                        	end                
                       else cdordst.cd_add_inf_cval1 end as ord_st_nm
                , temp.ch_cd
                , temp.ch_nm
                , temp.ord_dlv_knd_cd
                , temp.gds_typ_dtl_cd
                , temp.gds_cd
                , temp.pgc_gds_cd
                , temp.csp_gds_cd
                , temp.gds_nm
                , temp.ord_gds_opt_cntn
                , temp.ord_qty
                , temp.obnd_qty
                , temp.cncl_qty
                , temp.ord_gds_pchs_prc
                , temp.margin_rate
                , temp.sell_price
                , temp.ord_dtm
                , temp.cncl_dtm
                , case when temp.ord_dlv_knd_cd = 'DLV' then cddlvst.comm_dtl_cd_nm else cdsndst.comm_dtl_cd_nm end as dlv_snd_st_nm
                , temp.dlv_snd_dtm
                , temp.dlv_co_nm
                , temp.invc_no
                , temp.ord_snd_gds_use_st_cd
                , temp.ord_snd_gds_use_cnt
                , temp.csp_cd
                , temp.csp_nm
                , temp.csp_shp_nm
                , temp.asp_ord_no
                , temp.clnt_ord_no
                , temp.member_type
                , temp.ordr_nm
                , temp.clnt_cd
                , temp.clnt_nm
                , temp.taxn_knd_cd
                , temp.welfare_type
                , temp.category_menu
                , temp.mgr_nm
                , temp.ord_typ_cd
                , temp.acss_dvc_cd
                , temp.evnt_cd
                , temp.dlgds_no
                , temp.live_purchase_yn
                , temp.ebookYn
                , temp.ebook_mst_gds_cd
                , temp.ebook_gds_cd
                , temp.ord_gds_mndr_insr_cntn
                , temp.cccrd_memo
                , usr.usr_nm as employee_name
				, usr.test_usr_yn
            from (
        select oob.user_key /* 유저키 */
        , oob.ord_no /* 주문번호 */
        , ogd.ord_gds_seq /* 장바구니번호 */
        , case
            when ogd2.ord_no is not null then oob.ord_st_cd
            else
                case
                    when oob.ord_dlv_knd_cd = 'DLV' and dg.dlv_gds_qty - coalesce(dg.dlv_cncl_gds_qty , 0) = 0 then 'CNCL'
                    when oob.ord_dlv_knd_cd = 'SND' and sog.ord_snd_qty - coalesce(sog.snd_cncl_qty, 0) = 0 then 'CNCL'
                    when oob.ord_dlv_knd_cd = 'INTG' and ogd.ord_gds_qty - coalesce(ogd.cncl_gds_qty, 0) = 0 then 'CNCL'
                    else oob.ord_st_cd
                end
            end as ord_st_cd /* 주문상태코드 */
        , ogd.ch_cd /* 채널코드 */
        , ch.ch_nm /* 채널명 */
        , oob.ord_dlv_knd_cd /* 주문배송종류코드*/
        , case
            when ogd.ch_cd = '105' then pagd.gds_typ_dtl_cd
            else pgc.gds_typ_dtl_cd
            end as gds_typ_dtl_cd /* 상품유형상세코드 */
        , coalesce(ogd.gds_cd, ogd.csp_gds_cd) as gds_cd /* 상품코드 */
        , ogd.gds_cd as pgc_gds_cd/* 통합상품코드 */
        , ogd.csp_gds_cd /* 협력사상품코드 */
        , ogd.gds_nm /* 상품명 */
        , replace(ogd.ord_gds_opt_cntn,   '<br/>'  , ' ') as ord_gds_opt_cntn /* 옵션 */
        , case
            when oob.ord_dlv_knd_cd = 'DLV' then dg.dlv_gds_qty
            when oob.ord_dlv_knd_cd = 'SND' then sog.ord_snd_qty
            when oob.ord_dlv_knd_cd = 'INTG' then ogd.ord_gds_qty
            end as ord_qty /* 주문배송(발송)수량 */
        , case when oob.ord_dlv_knd_cd = 'DLV'
            then case when dlv.dlv_st_cd = 'DLV' or dlv.dlv_st_cd = 'CMPT'
                then dg.dlv_gds_qty
                else 0
                end
            else null
            end as obnd_qty /* 출고수량 */
        , case
            when ogd2.ord_no is not null then
                case
                    when oob.ord_st_cd = 'CNCL'
                    then ogd.cncl_gds_qty
                    else 0
                end
            else
                case
                    when oob.ord_dlv_knd_cd = 'DLV' then coalesce(dg.dlv_cncl_gds_qty , 0)
                    when oob.ord_dlv_knd_cd = 'SND' then coalesce(sog.snd_cncl_qty, 0)
                    when oob.ord_dlv_knd_cd = 'INTG' then coalesce(ogd.cncl_gds_qty, 0)
                    end
            end as cncl_qty /* 주문배송(발송)취소수량 */
        , case
            when cstb.txaf_evdn_knd_cd = 'T'
                and cstb.cms_stl_inf_use_yn = 'Y'
                and coalesce(ogd.csp_cms_knd_cd, csp.csp_cms_knd_cd) = '01'
            then null
            else (ogd.ord_gds_pchs_prc * (case
                when oob.ord_dlv_knd_cd = 'DLV' then dg.dlv_gds_qty
                when oob.ord_dlv_knd_cd = 'SND' then sog.ord_snd_qty
                when oob.ord_dlv_knd_cd = 'INTG' then ogd.ord_gds_qty
            end))
            end as ord_gds_pchs_prc /* 매입가 */
        , case
            when cstb.txaf_evdn_knd_cd = 'T'
                and cstb.cms_stl_inf_use_yn = 'Y'
                and coalesce(ogd.csp_cms_knd_cd,csp.csp_cms_knd_cd) = '01'
            then coalesce(ogd.csp_gds_cms_rt * 100, 0)
            else coalesce(ogd.ord_gds_cms_rt, 0)
            end as margin_rate /* 주문당시 수익률 */
        , (ogd.ord_gds_sell_prc * (case
            when oob.ord_dlv_knd_cd = 'DLV' then dg.dlv_gds_qty
            when oob.ord_dlv_knd_cd = 'SND' then sog.ord_snd_qty
            when oob.ord_dlv_knd_cd = 'INTG' then ogd.ord_gds_qty
            end)) as sell_price /* 판매가 */
        , oob.ord_dtm /* 주문일시 */
        , case
            when oob.ord_dlv_knd_cd = 'DLV' then dg.dlv_cncl_dtm
            when oob.ord_dlv_knd_cd = 'SND' then sog.snd_cncl_dtm
            when oob.ord_dlv_knd_cd = 'INTG' then case when ogd.ord_gds_qty = ogd.cncl_gds_qty then oob.cncl_dtm end
            end as cncl_dtm /* 주문취소일시 */
        , case
            when oob.ord_dlv_knd_cd = 'DLV' and dg.dlv_gds_qty - coalesce(dg.dlv_cncl_gds_qty , 0) = 0 then 'CNCL'
            else dlv.dlv_st_cd
            end as dlv_st_cd /* 배송상태코드 */
        , sog.rep_ord_snd_st_cd /* 대표발송상태코드 */
        , case when oob.ord_dlv_knd_cd = 'DLV' then to_char(to_timestamp(dlv.dlv_cmpt_dtm, 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD') else to_char(to_timestamp(sog.snd_dtm, 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD') end as dlv_snd_dtm /* 배송(발송)완료일자 */
        , codlv.dlv_co_nm /* 택배사명 */
        , dlv.invc_no /* 송장번호 */
        , case
            when oob.ord_dlv_knd_cd = 'SND' and sog.has_used = 1 then '03'
            when oob.ord_dlv_knd_cd = 'SND' and sog.all_unusable = 1 then '04'
            when oob.ord_dlv_knd_cd = 'SND' then '02'
            else null
            end as ord_snd_gds_use_st_cd /* 발송상품 사용상태 */
        , case when oob.ord_dlv_knd_cd = 'SND' then sog.used_cnt else null end as ord_snd_gds_use_cnt /* 발송상품 사용 건수 */
        , csp.csp_cd /* 협력사코드 */
        , csp.csp_nm /* 협력사명 */
        , pgc.csp_shp_nm /* 협력사매장명 */
        , case when ogd.ch_cd in ('111') then '' else oob.asp_ord_no end as asp_ord_no/* ASP 주문번호 */
        , oob.clnt_ord_no /* 고객사 주문번호 */
        , case when oob.fam_mem_no is null then '임직원' else '가족회원' end as member_type /* 회원구분 */
        , oob.ordr_nm /* 주문자명 */
        , oob.clnt_cd /* 고객사코드 */
        , clnt.clnt_nm /* 고객사명 */
        , ogd.taxn_knd_cd /* 면과세 */
        , case
            when ch.gds_dsp_bsic_knd_cd = 'CAT' then
                case ogd.hezo_std_ctgr_wsp_aply_cd
                    when 'WEL' then '복지'
                    when 'NOWEL' then '비복지'
                    when 'MIX' then '혼합'
                    else ogd.hezo_std_ctgr_wsp_aply_cd
                end
            when ch.gds_dsp_bsic_knd_cd in ('MNU', 'NON') then
                case
                    when exists (
                        select 1
                        from ez_or.or_ord_pymt_mns_gds_r opgr
                            join ez_or.or_ord_pymt_mns_cond_b opcb on opcb.ord_no = opgr.ord_no and opcb.ord_pymt_mns_cond_seq = opgr.ord_pymt_mns_cond_seq
                        where opgr.ord_no = ogd.ord_no
                            and opgr.ord_gds_seq = ogd.ord_gds_seq
                            and opcb.pymt_mns_cd in ('1001', '1008') /* 복지포인트, 특별포인트 */
                    ) then '복지'
                    else '비복지'
                end
            else '비복지'
        end as welfare_type  /* 복지구분 */
        , case
            when ch.gds_dsp_bsic_knd_cd = 'CAT' then
                concat_ws(' > '
                    , depth1.std_ctgr_nm
                    , depth2.std_ctgr_nm
                    , depth3.std_ctgr_nm
                    , depth4.std_ctgr_nm)
            when ch.gds_dsp_bsic_knd_cd = 'MNU' or ch.gds_dsp_bsic_knd_cd = 'NON' then
                menu.std_menu_nm
        end as category_menu /* 카테고리/메뉴 :: 카테고리 depth 전체 표시, 메뉴마스터명 표시 */
        , md.mgr_nm /* MD명 */
        , oob.ord_typ_cd /* 주문유형 */
        , oob.acss_dvc_cd /* 주문디바이스 */
        , ogd.evnt_cd /* 기획전유입코드 */
        , ogd.dlgds_no /* 딜코드 */
        , case when ogd.ezlive_no is null then 'N' else 'Y' END as live_purchase_yn /* 라이브구매여부 */
        , (select case when count(*)   >   0 then 'Y' else 'N' end
                    from ez_or.or_ord_gds_d
                    where ord_no = oob.ord_no
                    and ch_cd = '121') AS ebookYn /* EzEbook 여부 */
        , egd.ebook_mst_gds_cd  /* 전자도서마스터상품코드 */
        , egd.ebook_gds_cd      /* 전자도서상품코드 */
        , ogd.ord_gds_mndr_insr_cntn /*주문상품 필수입력내용*/
        , dda.cccrd_memo	/*경조카드메모*/                     
        from ez_or.or_ord_b oob
            join ez_or.or_ord_gds_d ogd on oob.ord_no = ogd.ord_no
            left outer join ez_pd.pd_gds_c pgc on ogd.gds_cd = pgc.gds_cd
            left outer join ez_pd.pd_alli_gds_d pagd on ogd.gds_cd = pagd.gds_cd
            join ez_cm.cm_ch_b ch on ogd.ch_cd = ch.ch_cd
            join ez_co.co_csp_b csp on ogd.csp_cd = csp.csp_cd
            join ez_ct.ct_clnt_b clnt on clnt.clnt_cd = oob.clnt_cd
            left outer join ez_co.co_stl_tmpl_b cstb on cstb.stl_tmpl_seq = ogd.stl_tmpl_seq
            left outer join ez_or.dl_dlv_gds_d dg on oob.ord_no = dg.ord_no and ogd.ord_gds_seq = dg.ord_gds_seq
            left outer join ez_or.dl_dlv_b dlv on dg.dlv_no = dlv.dlv_no and dlv.clm_no is null
            left outer join ez_or.dl_dlv_adr_b dda on oob.ord_no = dda.ord_no and dlv.dlv_adr_no = dda.dlv_adr_no
            left outer join ez_co.co_dlv_co_b codlv on dlv.dlv_co_cd = codlv.dlv_co_cd
            left outer join ez_dp.dp_std_ctgr_b depth4 on pgc.mng_std_ctgr_cd = depth4.std_ctgr_cd
            left outer join ez_dp.dp_std_ctgr_b depth3 on depth4.high_std_ctgr_cd = depth3.std_ctgr_cd
            left outer join ez_dp.dp_std_ctgr_b depth2 on depth3.high_std_ctgr_cd = depth2.std_ctgr_cd
            left outer join ez_dp.dp_std_ctgr_b depth1 on depth2.high_std_ctgr_cd = depth1.std_ctgr_cd
            left outer join lateral (
            	select * from ez_dp.dp_std_menu_hezo_r 
            	where (
	            		(oob.ord_typ_cd = 'SS' and hezo_no in ('713', ogd.hezo_no)) 
	            		or (oob.ord_typ_cd != 'SS' and hezo_no = ogd.hezo_no)
            		) 
            		and hezo_menu_cd = coalesce(ogd.pymt_hezo_menu_cd, ogd.hezo_menu_cd)
            	limit 1
            ) mhr on true
            left outer join ez_dp.dp_std_menu_b menu on menu.std_menu_cd = mhr.std_menu_cd
            left outer join lateral (
                select mdb.mgr_md_no
                    , mgrb.mgr_nm
                from ez_cm.cm_mgr_md_b mdb
                    join ez_cm.cm_mgr_b mgrb on mgrb.mgr_id = mdb.mgr_id
                where mdb.mgr_md_no = ogd.mgr_md_no
                offset 0
            ) md on true
            left outer join lateral (
                select dosgd.ord_no
                    , dosgd.ord_gds_seq
                    , case
                        when max(dosgd.ord_snd_st_cd) = '02'
                            and min(dosgd.ord_snd_st_cd) = '02'
                                then '02' -- 모두 발송완료
                        when max(dosgd.ord_snd_st_cd) = '03'
                            and min(dosgd.ord_snd_st_cd) = '03'
                                then '03' -- 모두 발송오류
                        when max(dosgd.ord_snd_st_cd) = '07'
                            and min(dosgd.ord_snd_st_cd) = '07'
                                then '07' -- 모두 발송취소
                        else (
                            case max (
                                case dosgd.ord_snd_st_cd
                                    when '03' then 1 -- 발송오류
                                    when '07' then 2 -- 발송취소
                                    when '00' then 3 -- 수락대기
                                    when '01' then 4 -- 발송대기
                                    when '06' then 5 -- 발송준비중
                                    when '08' then 6 -- 발송진행
                                    else 0 -- 발송완료
                                end
                            )
                                when 1 then '03'
                                when 2 then '07'
                                when 3 then '00'
                                when 4 then '01'
                                when 5 then '06'
                                when 6 then '08'
                                else '02'
                            end
                        )
                    end as rep_ord_snd_st_cd
                    , count(dosgd.ord_snd_seq) as ord_snd_qty
                    , sum(case when dosgd.ord_snd_st_cd = '07' then 1 else 0 end) as snd_cncl_qty
                    , max(dosgd.snd_dtm) as snd_dtm
                    , max(dosgd.snd_cncl_dtm) as snd_cncl_dtm
                    , max(case when dosgd.ord_snd_gds_use_st_cd = '03' then 1 else 0 end) as has_used
                    , min(case when dosgd.ord_snd_gds_use_st_cd = '04' then 1 else 0 end) as all_unusable
                    , sum(case when dosgd.ord_snd_gds_use_st_cd = '03' then 1 else 0 end) as used_cnt
                from ez_or.dl_ord_snd_gds_d dosgd
                where dosgd.ord_no = oob.ord_no
                    and dosgd.ord_gds_seq = ogd.ord_gds_seq
                    and dosgd.ord_snd_st_cd not in ('09') /* 09:수신자변경 */
                group by dosgd.ord_no, dosgd.ord_gds_seq
                offset 0
            ) sog on true
            left outer join ez_pd.pd_ebook_gds_d egd on egd.gds_cd = ogd.gds_cd /* 전자도서상품상세 */
            left outer join lateral (select ogd2.ord_no
                from ez_or.or_ord_gds_d ogd2
                where ogd2.ord_no = oob.ord_no
                    and ogd2.amt_chg_gds_yn = 'Y'
                limit 1) ogd2 on true
        where oob.ord_dtm between concat('20260830', '000000') and concat('20260916', '595959')         
        and oob.ord_st_cd not in ('WAIT', 'FAIL') /* 주문대기, 주문실패 건 제외 */
        and ogd.orgl_ord_gds_seq is null /* 취소수수료, 교환 상품 제외 */
        and ogd.cncl_cms_ocrn_gds_yn = 'N' /* 취소수수료발생상품 제외(취소수수료발생 시 주문상품이 새로 생성됨) */
        and ogd.amt_chg_gds_yn = 'N' /* 금액변경상품 제외 */
        and ((oob.ord_dlv_knd_cd = 'DLV' and dlv.dlv_obnd_typ_cd = 'ORD' and dg.dlv_gds_qty > 0) or (oob.ord_dlv_knd_cd = 'SND' and sog.ord_snd_qty > 0) or (oob.ord_dlv_knd_cd not in ('DLV', 'SND')))
/***************************/
/*slow 쿼리 조건 59,666ms*/ --2m23s
                    and ((
                        ogd.gds_cd in
                         (  
                            replace('1001039149827', ' ', '')
                         ) 
                    ) or (
                        ogd.csp_gds_cd in
                     (  
                        replace('1001039149827', ' ', '')
                     ) 
                    ))
                    and clnt.clnt_cont_usg_cd = 'GNRL'
/***************************/					
/*
화면에서 선택했을때 35가지 조건이 있음
기본조건)
oob.ord_dtm between concat(#{searchDateStart}, '000000') and concat(#{searchDateEnd}, '595959')
oob.ord_st_cd not in ('WAIT', 'FAIL') /* 주문대기, 주문실패 건 제외 */
ogd.orgl_ord_gds_seq is null /* 취소수수료, 교환 상품 제외 */
ogd.cncl_cms_ocrn_gds_yn = 'N' /* 취소수수료발생상품 제외(취소수수료발생 시 주문상품이 새로 생성됨) */
ogd.amt_chg_gds_yn = 'N' /* 금액변경상품 제외 */
((oob.ord_dlv_knd_cd = 'DLV' and dlv.dlv_obnd_typ_cd = 'ORD' and dg.dlv_gds_qty > 0) or (oob.ord_dlv_knd_cd = 'SND' and sog.ord_snd_qty > 0) or (oob.ord_dlv_knd_cd not in ('DLV', 'SND')))


조건1)
ogd.ch_cd = #{chCd}

조건2)
pgc.mng_std_ctgr_cd like concat(#{fullStdCtgrCd}, '%')

조건3)
menu.std_menu_cd = #{menuCd}

조건4)
ogd.gds_nm like '%' || #{searchWordText} || '%'

조건5)
((
          ogd.gds_cd in (#{gdsCd}, #{gdsCd})
       ) or (
          ogd.csp_gds_cd in (#{gdsCd}, #{gdsCd})
))

조건6)
oob.ordr_nm like '%' || #{searchWordText} || '%'

조건7)
replace(oob.ordr_mbl_telno, '-', '') = replace(#{searchWordText}, '-', '')


조건8)
((oob.ord_dlv_knd_cd = 'DLV' and dda.rcvr_nm like '%' || #{searchWordText} || '%')
                    or (oob.ord_dlv_knd_cd != 'DLV' and exists(
                        select 1
                        from ez_or.dl_ord_snd_b osb
                        where osb.ord_no = oob.ord_no
                            and osb.rcvr_nm like '%' || #{searchWordText} || '%'
                        ))
                    )

조건9)
((oob.ord_dlv_knd_cd = 'DLV' and replace(dda.rcvr_mbl_telno, '-', '') = replace(#{searchWordText}, '-', ''))
                        or (oob.ord_dlv_knd_cd != 'DLV' and exists(
                            select 1
                            from ez_or.dl_ord_snd_b osb
                            where osb.ord_no = oob.ord_no
                                and replace(osb.rcvr_mbl_telno, '-', '') = replace(#{searchWordText}, '-', '')
                            ))
                    )


조건10)
ogd.mgr_md_no in (#{mdNo}::numeric, #{mdNo}::numeric, #{mdNo}::numeric)

조건11)
clnt.clnt_cd = #{clntCd}

조건12)
oob.ord_dlv_knd_cd = 'DLV'

조건13)
oob.ord_dlv_knd_cd in ('SND', 'INTG')

조건14)
oob.ord_dlv_knd_cd in ('SND', 'INTG')
oob.ord_st_cd in (#{item}, #{item}, #{item})

조건15)
oob.ord_dlv_knd_cd = 'DLV'

조건16)
oob.ord_dlv_knd_cd = 'DLV'
dlv.dlv_st_cd = #{deliveryStatus}

조건17)
oob.ord_dlv_knd_cd in ('SND', 'INTG')

조건18)
oob.ord_dlv_knd_cd in ('SND', 'INTG')
sog.rep_ord_snd_st_cd = #{deliveryStatus}

조건19)
pgc.gds_typ_dtl_cd = #{gdsTypDtlCd}

조건20)
clnt.clnt_cls_cd in (#{clntClsCd}, #{clntClsCd}, #{clntClsCd})

조건21)
exists (
                select 1
                from ez_ct.ct_sls_cont_b cscb
                where cscb.clnt_cd = oob.clnt_cd
                    and cscb.bz_fld_cd in (#{bzFldCd}, #{bzFldCd}, #{bzFldCd})
            )

조건22)
ogd.hezo_std_ctgr_wsp_aply_cd = #{welfareType}

조건23)
sog.has_used = 1

조건24)
sog.all_unusable = 1

조건25)
sog.has_used = 0
sog.all_unusable = 0

조건26)
csp.csp_cd = #{contentServiceProviderCode}

조건27)
clnt.clnt_cont_usg_cd = 'GNRL'

조건28)
clnt.clnt_cont_usg_cd = 'LINK'

조건29)
clnt.clnt_cont_usg_cd = 'TEST'

조건30)
oob.acss_dvc_cd in ('MAPP', 'MWEB', 'MALL')

조건31)
oob.acss_dvc_cd = #{acssDvcCd}

조건32)
oob.fam_mem_no is null

조건33)
oob.fam_mem_no is not null

조건34)
oob.ord_typ_cd = #{ordTypCd}

조건35)
exists (
                select 1
                from ez_or.py_pymt_b ppb
                where ppb.ord_no = oob.ord_no
                    and ppb.pymt_div_cd = 'PYMT'
                    and ppb.pymt_st_cd = 'CMPT'
                    and ppb.clm_no is null
                    and ppb.pymt_mns_cd in (#{pymtMnsCd}, #{pymtMnsCd}, #{pymtMnsCd})
            )
*/
                 ) temp
            left outer join ez_cm.cm_comm_dtl_c cdordst on cdordst.comm_cd = 'ord_st_cd' and cdordst.comm_dtl_cd = temp.ord_st_cd
            left outer join ez_cm.cm_comm_dtl_c cddlvst on cddlvst.comm_cd = 'dlv_st_cd' and cddlvst.comm_dtl_cd = temp.dlv_st_cd
            left outer join ez_cm.cm_comm_dtl_c cdsndst on cdsndst.comm_cd = 'ord_snd_st_cd' and cdsndst.comm_dtl_cd = temp.rep_ord_snd_st_cd
            left outer join lateral (
				select s1.test_usr_yn, s2.usr_nm from ez_ct.ct_usr_b s1 join ez_pi.pi_usr_pi_d s2 on s1.user_key = s2.user_key
				where 
					s1.user_key = temp.user_key
				union all
				select s1.test_usr_yn, s2.usr_nm from ez_ct.ct_usr_b s1 join ez_pp.pp_npa_usr_pi_d s2 on s1.user_key = s2.user_key
				where 
					s1.user_key = temp.user_key
			) usr on true
            order by temp.ord_dtm desc, temp.ord_no desc, temp.ord_gds_seq
        ) temp2         
            where temp2.test_usr_yn = 'N' LIMIT 50