/* com.ezwelesp.fo.product.rest.display.life.tour.hanatour.mapper.query.DisplayLifeTourHanatourQueryMapper.selectSearchLayoutForMinMaxPrice */
SELECT COALESCE(MIN(trip_gds_dsp_lwst_prc),0) AS minPrice, COALESCE(MAX(trip_gds_dsp_hgst_prc),0) AS maxPrice

        FROM ez_pd.pd_trip_gds_rps_gds_b REP
        WHERE trim(REP.use_yn) = 'Y'
              AND REP.sell_end_dt >= TO_CHAR(NOW(), 'YYYYMMDD')
            AND EXISTS (
            SELECT 1
              FROM ez_pd.pd_trip_gds_sell_gds_b SALE
              JOIN ez_pd.pd_trip_gds_prc_d PRICE ON SALE.sell_trip_gds_cd = PRICE.sell_trip_gds_cd
               AND PRICE.trip_gds_age_div_cd = 'A'
              WHERE REP.rps_trip_gds_cd = SALE.rps_trip_gds_cd AND trim(SALE.use_yn) = 'Y'
                  /* 출발일 검색 */
                    AND SALE.dptr_dt   >=   '20260924'


                        AND SALE.dptr_dt    <=   '20260927'

                    OFFSET 0



            )



            AND EXISTS (
                        SELECT REP.rps_trip_gds_cd
                        FROM ez_pd.pd_trip_gds_rps_gds_b REP1
                        WHERE REP1.rps_trip_gds_cd = REP.rps_trip_gds_cd
                          AND REP.use_yn = 'Y' AND REP.trip_cnry_cd IN
                         (  
                            'BN'
                         , 
                            'KH'
                         , 
                            'LA'
                         , 
                            'IN'
                         , 
                            'NP'
                         ) 
                        UNION ALL
                        SELECT DEST.rps_trip_gds_cd
                        FROM ez_pd.pd_trip_gds_rps_gds_thrgh_r DEST
                        WHERE DEST.rps_trip_gds_cd = REP.rps_trip_gds_cd
                          AND DEST.trip_cnry_cd IN
                         (  
                            'BN'
                         , 
                            'KH'
                         , 
                            'LA'
                         , 
                            'IN'
                         , 
                            'NP'
                         ) 

                            UNION ALL
                            SELECT REP2.rps_trip_gds_cd
                                FROM ez_pd.pd_trip_gds_rps_gds_b REP2
                            WHERE REP2.rps_trip_gds_cd = REP.rps_trip_gds_cd
                              AND REP2.use_yn = 'Y' AND REP2.trip_city_cd IN
                             (  
                                'SIN'
                             , 
                                'BKK'
                             , 
                                'PYX'
                             , 
                                'HKT'
                             , 
                                'CNX'
                             , 
                                'CEI'
                             , 
                                'USM'
                             , 
                                'DAD'
                             , 
                                'AX3'
                             , 
                                'NHA'
                             , 
                                'DLI'
                             , 
                                'PQC'
                             , 
                                'HAN'
                             , 
                                'B48'
                             , 
                                'SGN'
                             , 
                                'CEB'
                             , 
                                'KLO'
                             , 
                                'TAG'
                             , 
                                'CPK'
                             , 
                                'MNL'
                             , 
                                'BKI'
                             , 
                                'DPS'
                             ) 
                            UNION ALL
                            SELECT DEST2.rps_trip_gds_cd
                            FROM ez_pd.pd_trip_gds_rps_gds_thrgh_r DEST2
                            WHERE DEST2.rps_trip_gds_cd = REP.rps_trip_gds_cd
                              AND DEST2.trip_city_cd IN
                             (  
                                'SIN'
                             , 
                                'BKK'
                             , 
                                'PYX'
                             , 
                                'HKT'
                             , 
                                'CNX'
                             , 
                                'CEI'
                             , 
                                'USM'
                             , 
                                'DAD'
                             , 
                                'AX3'
                             , 
                                'NHA'
                             , 
                                'DLI'
                             , 
                                'PQC'
                             , 
                                'HAN'
                             , 
                                'B48'
                             , 
                                'SGN'
                             , 
                                'CEB'
                             , 
                                'KLO'
                             , 
                                'TAG'
                             , 
                                'CPK'
                             , 
                                'MNL'
                             , 
                                'BKI'
                             , 
                                'DPS'
                             ) 
                            UNION ALL
                            SELECT SALE.rps_trip_gds_cd
                            FROM ez_pd.pd_trip_gds_sell_gds_b SALE
                            WHERE SALE.rps_trip_gds_cd = REP.rps_trip_gds_cd
                              AND trim(SALE.use_yn) = 'Y' AND trim(SALE.arvl_trip_city_cd) IN
                             (  
                                'SIN'
                             , 
                                'BKK'
                             , 
                                'PYX'
                             , 
                                'HKT'
                             , 
                                'CNX'
                             , 
                                'CEI'
                             , 
                                'USM'
                             , 
                                'DAD'
                             , 
                                'AX3'
                             , 
                                'NHA'
                             , 
                                'DLI'
                             , 
                                'PQC'
                             , 
                                'HAN'
                             , 
                                'B48'
                             , 
                                'SGN'
                             , 
                                'CEB'
                             , 
                                'KLO'
                             , 
                                'TAG'
                             , 
                                'CPK'
                             , 
                                'MNL'
                             , 
                                'BKI'
                             , 
                                'DPS'
                             ) 

            )