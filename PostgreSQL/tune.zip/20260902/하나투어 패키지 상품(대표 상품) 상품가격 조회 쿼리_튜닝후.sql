explain (analyze, buffers)
WITH destination_rps AS MATERIALIZED
(
    SELECT DISTINCT
           s.rps_trip_gds_cd
    FROM ez_pd.pd_trip_gds_sell_gds_b s
    WHERE s.arvl_trip_city_cd IN
    (
        'SIN','BKK','PYX','HKT','CNX','CEI','USM',
        'DAD','AX3','NHA','DLI','PQC','HAN','B48',
        'SGN','CEB','KLO','TAG','CPK','MNL','BKI','DPS'
    )
    AND s.use_yn = 'Y'
),
through_rps AS MATERIALIZED
(
    SELECT DISTINCT
           t.rps_trip_gds_cd
    FROM ez_pd.pd_trip_gds_rps_gds_thrgh_r t
    WHERE t.trip_cnry_cd IN ('BN','KH','LA','IN','NP')
       OR t.trip_city_cd IN
       (
           'SIN','BKK','PYX','HKT','CNX','CEI','USM',
           'DAD','AX3','NHA','DLI','PQC','HAN','B48',
           'SGN','CEB','KLO','TAG','CPK','MNL','BKI','DPS'
       )
)
SELECT
    COALESCE(MIN(r.trip_gds_dsp_lwst_prc), 0) AS minPrice,
    COALESCE(MAX(r.trip_gds_dsp_hgst_prc), 0) AS maxPrice
FROM ez_pd.pd_trip_gds_rps_gds_b r
WHERE r.use_yn = 'Y'
  AND r.sell_end_dt >= TO_CHAR(NOW(), 'YYYYMMDD')

  /* 국가 */
  AND
  (
      r.trip_cnry_cd IN ('BN','KH','LA','IN','NP')

      /* 도시 */
      OR r.trip_city_cd IN
      (
          'SIN','BKK','PYX','HKT','CNX','CEI','USM',
          'DAD','AX3','NHA','DLI','PQC','HAN','B48',
          'SGN','CEB','KLO','TAG','CPK','MNL','BKI','DPS'
      )

      /* 경유 */
      OR r.rps_trip_gds_cd IN
      (
          SELECT rps_trip_gds_cd
          FROM through_rps
      )

      /* 도착 */
      OR r.rps_trip_gds_cd IN
      (
          SELECT rps_trip_gds_cd
          FROM destination_rps
      )
  )

  /* 출발일 + 가격 존재 */
  AND EXISTS
  (
      SELECT 1
      FROM ez_pd.pd_trip_gds_sell_gds_b s
      JOIN ez_pd.pd_trip_gds_prc_d p
        ON p.sell_trip_gds_cd = s.sell_trip_gds_cd
       AND p.trip_gds_age_div_cd = 'A'
      WHERE s.rps_trip_gds_cd = r.rps_trip_gds_cd
        AND s.dptr_dt BETWEEN '20260924' AND '20260927'
        AND s.use_yn = 'Y'
  );