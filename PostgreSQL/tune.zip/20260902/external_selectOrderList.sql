/* com.ezwelesp.ex.order.rest.hpas.mapper.query.HpasOrderListQueryMapper.selectOrderList */
/* 주문목록 조회 */

explain(ANALYZE, BUFFERS) 
		with oob as (
			         select oob.* 
		               from ez_or.or_ord_b oob
		              where 1=1
				        and ord_st_cd not in ('WAIT', 'FAIL') /* 주문대기, 주문실패 건 제외 */
					            and exists (
										select 1 
										from ez_or.cl_clm_b ccb
										where ccb.clm_knd_cd = 'CNCL'
										and ccb.ord_no = oob.ord_no
										and ccb.clm_cmpt_dtm  >=  '20260601' || '000000'
										and ccb.clm_cmpt_dtm  <=  '20260831' || '235959'
								)
			        )
		select oob.ord_no
		     , oob.asp_ord_no
		     , oob.ordr_nm
		     , oob.ordr_telno
		     , oob.ordr_mbl_telno
		     , oob.pcc
		     , oob.ord_dtm
		     , oob.ord_st_cd
		     , oob.acss_dvc_cd
		     , oob.ord_typ_cd
		     /* 배송지정보 */
		     , ddab.dlv_adr_no
		     , dlvexp.dlv_exp
			 , dlvexp.ismt_add_dlv_exp
			 , dlvexp.arpay_rmtt_dlv_exp
             , dlvexp.jeju_add_dlv_exp
			 , ddab.rcvr_nm
			 , ddab.rcvr_telno
			 , ddab.rcvr_mbl_telno
			 , ddab.rcvr_zipcd
			 , ddab.rcvr_bas_adr
			 , ddab.rcvr_dtl_adr
			 , ddab.dlv_req_cntn
			 /* 선물하기 정보 추가 */
			 , gift.gvgft_ord_st_cd
			 , gift.prsn_msg_cntn
			 /* 화면 기준 선물메세지 발송시간 = 주문일시. 추후 확인 필요 */
			 , case when gift.prsn_msg_cntn is not null then oob.ord_dtm end as prsn_msg_snd_dtm
			 /* 배송정보	 */		 
		     , ddb.dlv_no 
		     , ddb.csp_cd
		     , ddb.csp_obnd_loc_no
		     , ddb.invc_no
		     , ddb.dlv_co_cd
		     , ddb.dlv_st_cd
		     , ddb.dlv_strt_dtm
		     , ddb.dlv_cmpt_dtm
		     /* 상품정보 */
		     , oogd.ord_gds_seq
		     , oogd.orgl_ord_gds_seq
		     , oogd.frst_ord_gds_seq
		     , ddgd.dlv_gds_seq
		     , oogd.gds_cd
		     , oogd.gds_nm
		     , ddgd.dlv_gds_qty
		     , ddgd.dlv_gds_st_cd
		     , ddgd.dlv_cncl_dtm
		     , oogd.opt_gds_comb_seq
		     , replace(oogd.ord_gds_opt_cntn, ';', ':') as ord_gds_opt_cntn /* 옵션 */
		     , oogd.csp_gds_cd
		     , case when cstb.txaf_evdn_knd_cd = 'T'
                     and cstb.cms_stl_inf_use_yn = 'Y'
                     and coalesce(oogd.csp_cms_knd_cd, csp.csp_cms_knd_cd) = '01'
                    then null 
                    else oogd.ord_gds_pchs_prc end as pchs_prc    /* 매입가 */
             , case when cstb.txaf_evdn_knd_cd = 'T'
                     and cstb.cms_stl_inf_use_yn = 'Y'
                     and coalesce(oogd.csp_cms_knd_cd, csp.csp_cms_knd_cd) = '01'
                    then coalesce(oogd.csp_gds_cms_rt, 0)
                    else coalesce(oogd.ord_gds_cms_rt, 0)
                         end as ord_gds_cms_rt    /* 주문당시 수익률 */
		     , oogd.ord_gds_sell_prc as sell_prc
		     , oogd.opt_sell_prc
		     , cpn.cpn_use_amt as dc_amt
		     , oogd.nrml_sell_prc
		     , oogd.ord_gds_qty
		     , clm.tot_cncl_qty
		     , clm.cncl_qty
		     , clm.rtp_cncl_qty
		     , clm.ostk_cncl_qty
		     , ddb.dlv_obnd_typ_cd
		     , clm.clm_exch_gds_qty
		  from oob
		  /* 속도개선을 위하여 join 방식 변경 */
		inner join lateral (select *
        					from ez_or.dl_dlv_b ddb
                            where ddb.ord_no = oob.ord_no
                            and ddb.dlv_obnd_typ_cd not in ('WTWD')
			and ddb.dlv_st_cd = 'STBY' 
                            offset 0) ddb on 1=1     
		 inner join ez_or.dl_dlv_adr_b ddab
		    on ddab.ord_no = ddb.ord_no                                                                          
           and ddab.dlv_adr_no = ddb.dlv_adr_no                                                                  		  
		 join lateral (select usr.usr_nm                                                                         
                            , usr.test_usr_yn                                                                    
                         from ez_ct.vw_ct_usr_b usr                                                              
                         where oob.user_key = usr.user_key                                                       
                           and usr.test_usr_yn = 'N'                                                             
                        offset 0) usr on 1=1                                                                     
		 left outer join lateral (select sum(exp.dlv_exp) as dlv_exp                      
                                  , sum(exp.ismt_add_dlv_exp) as ismt_add_dlv_exp
                                  , sum(exp.arpay_rmtt_dlv_exp) as arpay_rmtt_dlv_exp
                                  , sum(exp.jeju_add_dlv_exp) as jeju_add_dlv_exp
                                  , dlv.ord_no
                                  , dlv.dlv_adr_no
                               from ez_or.dl_dlv_b dlv
                              inner join ez_or.dl_dlv_exp_b exp 
                                 on dlv.dlv_exp_no = exp.dlv_exp_no
                              where dlv.ord_no = oob.ord_no
                                and dlv.csp_cd = '10091950'
                                and dlv.dlv_obnd_typ_cd = 'ORD'
                                and dlv.divd_dlv_yn = 'N'
                              group by dlv.dlv_adr_no, dlv.ord_no
							 offset 0                                                                            
                            ) dlvexp 
            on dlvexp.dlv_adr_no = ddab.dlv_adr_no and dlvexp.ord_no = ddab.ord_no
         inner join lateral (select *
                               from ez_or.dl_dlv_gds_d ddgd 
                              where ddgd.dlv_no = ddb.dlv_no
                                and ddgd.ord_no = oob.ord_no
                                and ddgd.dlv_gds_qty > 0
                             offset 0) ddgd on 1=1                                                               
		 inner join lateral (select *
		                       from ez_or.or_ord_gds_d oogd
                              where oogd.ord_no = oob.ord_no
                                and oogd.ord_gds_seq = ddgd.ord_gds_seq                                 
            					and oogd.cncl_gds_qty > 0            					 
                             offset 0) oogd on 1=1                                                               
         inner join ez_co.co_csp_b csp on oogd.csp_cd = csp.csp_cd   
         left outer join lateral (select ordcpn.ord_no                              
                                       , ordcpn.ord_gds_seq
                                       , sum(ordcpn.cpn_use_amt) as cpn_use_amt
                                    from (
                                         select sum(oocd.cpn_use_amt) as cpn_use_amt /* 사용취소 시 케이스 적용 필요 */
                                              , oocd.ord_no
                                              , oocd.ord_gds_seq
                                           from ez_or.or_ord_cpn_d oocd
                                          where oocd.ord_gds_seq is not null
			   								and oocd.cpn_use_cncl_yn = 'N'
			   								and oocd.clm_no is null
                                            and oocd.ord_no = oob.ord_no             
                                          group by oocd.ord_no, oocd.ord_gds_seq
                                         union all 
                                         select sum(oocgd.cpn_use_amt) as cpn_use_amt /* 사용취소 시 케이스 적용 필요*/
                                              , oocgd.ord_no
                                              , oocgd.ord_gds_seq
                                           from ez_or.or_ord_cpn_gds_d oocgd
                                          inner join ez_or.or_ord_cpn_d ooc on oocgd.ord_cpn_no = ooc.ord_cpn_no and ooc.cpn_use_cncl_yn = 'N'
                                          where oocgd.ord_no = oob.ord_no             
                                          group by oocgd.ord_no, oocgd.ord_gds_seq 
                                         ) ordcpn 
                                   group by ordcpn.ord_no, ordcpn.ord_gds_seq
                                   offset 0
                                 ) cpn 
            on (cpn.ord_no = oob.ord_no and cpn.ord_gds_seq = oogd.ord_gds_seq)             
         left outer join lateral (select ccgd.ord_no
                                        , ccgd.ord_gds_seq
                                        , ccgd.dlv_no                                  
                                        , ccgd.dlv_gds_seq
                                        , sum(case when ccb.clm_knd_cd in ('CNCL', 'AMTC', 'RTP') then ccgd.clm_gds_qty - ccgd.cncl_qty else 0 end) as tot_cncl_qty
                                        , sum(case when ccb.clm_knd_cd in ('CNCL', 'AMTC') and ccrl.clm_rsn_cd   <>   '1005' then ccgd.clm_gds_qty - ccgd.cncl_qty else 0 end) as cncl_qty
                                        , sum(case when ccb.clm_knd_cd = 'RTP' then ccgd.clm_gds_qty - ccgd.cncl_qty else 0 end) as rtp_cncl_qty
                                        , sum(case when ccb.clm_knd_cd in ('CNCL', 'AMTC') and ccrl.clm_rsn_cd = '1005' then ccgd.clm_gds_qty - ccgd.cncl_qty else 0 end) as ostk_cncl_qty
                                        , sum(case when ccb.clm_knd_cd = 'EXCH' then ccgd.clm_gds_qty - ccgd.cncl_qty else 0 end) as clm_exch_gds_qty
                                     from ez_or.cl_clm_b ccb                            
                                    inner join ez_or.cl_clm_gds_d ccgd
                                       on ccgd.clm_no = ccb.clm_no
                                    inner join ez_or.cl_clm_rsn_l ccrl   
                                       on ccgd.clm_no = ccrl.clm_no
                                      and ccgd.clm_gds_seq = ccrl.clm_gds_seq
                                    where ccb.ord_no = oogd.ord_no
					                  and ccgd.ord_gds_seq = oogd.ord_gds_seq
		                  		      and ddb.dlv_no = ccgd.dlv_no
		                 		      and ddgd.dlv_gds_seq = ccgd.dlv_gds_seq       
                                      and ccb.clm_st_cd not in ('WTDR')            
                                    group by ccgd.ord_no, ccgd.ord_gds_seq, ccgd.dlv_no, ccgd.dlv_gds_seq
                                    offset 0
                                  ) clm  
		    on true    
		 left outer join ez_or.or_gvgft_ord_b gift 
		   on gift.ord_no = oob.ord_no             
		 left outer join ez_co.co_stl_tmpl_b cstb 
		   on cstb.stl_tmpl_seq = oogd.stl_tmpl_seq  
		 where (oogd.csp_cd = '10091950' or oob.ord_dtm is null)  /* 실행계획이 변경되지 않도록 무의미한 OR 조건 추가 */	
		   and (ddb.csp_cd = '10091950' or oob.ord_dtm is null)   /* 실행계획이 변경되지 않도록 무의미한 OR 조건 추가 */
		     and ddb.dlv_st_cd  <>  'INSR_STBY'		    
		   and oogd.orgl_ord_gds_seq is null /* 취소수수료, 교환 상품 제외 */		        
           and oogd.cncl_cms_ocrn_gds_yn = 'N' /* 취소수수료발생상품 제외(취소수수료발생 시 주문상품이 새로 생성됨) */
           and oogd.amt_chg_gds_yn = 'N'       /* 금액변경상품 제외 */
           and (ddb.dlv_obnd_typ_cd in ('ORD') or (ddb.dlv_obnd_typ_cd = 'EXCH' and (ddb.dlv_st_cd not in ('CNCL') or ddb.dlv_st_cd is null)))                   
		 order by oob.ord_no, ddab.dlv_adr_no, ddb.dlv_no, oogd.ord_gds_seq