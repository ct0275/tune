WITH code_list AS
(
    SELECT comm_dtl_cd AS cd
    FROM ez_cm.cm_comm_dtl_c
    WHERE comm_cd = 'ldg_ord_rsv_st_cd'
      AND cd_add_inf_cval1 = 'Y'
      AND cd_add_inf_cval2 = 'N'
      AND cd_add_inf_cval3 = 'N'
      AND use_yn = 'Y'
      AND comm_dtl_cd <> '1000'
),
order_cnt AS
(
    SELECT count(*) AS cnt,
           olob.ldg_ord_rsv_st_cd
    FROM ez_or.or_ldg_ord_b olob
    WHERE olob.aplr_nm = '김남철'
      AND olob.ord_dt BETWEEN '20250908' AND '20260908'
      AND olob.seas_div_cd = '1001'
      AND olob.ldg_grp_cd = '4001'
      AND olob.accm_br_cd = '10048'
      AND EXISTS
      (
          SELECT 1
          FROM ez_ct.ct_usr_b ub
          WHERE ub.user_key = olob.user_key
            AND ub.clnt_cd = olob.clnt_cd
      )
    GROUP BY olob.ldg_ord_rsv_st_cd
)
SELECT COALESCE(oc.cnt, 0) AS cnt,
       cd.cd
FROM code_list cd
LEFT JOIN order_cnt oc
  ON cd.cd = oc.ldg_ord_rsv_st_cd
ORDER BY cd.cd;