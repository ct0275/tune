/* com.ezwelesp.bo.hims.customer.rest.lodgement.checkin.order.applylist.mapper.query.HimsOrderApplyListQueryMapper.selectHcasAllAplyStCdCnt */
WITH code_list AS materialized (
            SELECT comm_dtl_cd AS cd
            FROM ez_cm.cm_comm_dtl_c
            WHERE comm_cd = 'ldg_ord_rsv_st_cd'
            AND cd_add_inf_cval1 = 'Y'
            AND cd_add_inf_cval2 = 'N'
            AND cd_add_inf_cval3 = 'N'
            AND use_yn = 'Y'
            AND comm_dtl_cd != '1000'
        ),
        order_cnt AS materialized (
            SELECT count(1) AS cnt
                 , olob.ldg_ord_rsv_st_cd
            FROM ez_or.or_ldg_ord_b olob
             
	        INNER JOIN ez_ct.vw_ct_usr_b usr
	            ON usr.user_key = olob.user_key
	            AND usr.clnt_cd = olob.clnt_cd
	    	 
             
         WHERE  olob.aplr_nm = '김남철' /* 신청자 */
                        
                    
            
            
                AND olob.ord_dt BETWEEN '20250908' AND '20260908'
            
            
            
                AND olob.seas_div_cd = '1001' /*시즌구분코드*/
            
            
                AND olob.ldg_grp_cd = '4001'  /*숙박그룹코드*/
            
            
            
            
            
            
            
            
            
                AND olob.accm_br_cd = '10048' /*지점명*/ 
     
            GROUP BY olob.ldg_ord_rsv_st_cd
        )
        SELECT coalesce(olob.cnt, 0) as cnt
             , cd.cd
        FROM code_list cd
        LEFT JOIN (
            SELECT cnt
                 , ldg_ord_rsv_st_cd
            FROM order_cnt
            offset 0
        )olob
            ON cd.cd = olob.ldg_ord_rsv_st_cd
        ORDER BY cd.cd