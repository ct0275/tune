/* com.ezwelesp.bo.hims.product.rest.approval.mapper.query.HimsProductApprovalQueryMapper.selectProductApprovalList */
select
    a.gds_chg_no,
    clas.clas_type_nm as clasTypeNm,
    to_char(to_timestamp(r.gds_chg_chck_req_dtm,'YYYYMMDDHH24MISS'),'YYYY-MM-DD HH24:MI:SS') as gds_chg_chck_req_dtm,
    r.gds_chg_req_rsn_cntn,
    r.req_mgr_id,
    case when reqMgr.mgr_nm is not null then concat(reqMgr.mgr_nm,'(',r.req_mgr_id,')') else r.req_mgr_id end as reqMgrInfo,
    to_char(to_timestamp(apv.gds_chg_chck_dtm,'YYYYMMDDHH24MISS'),'YYYY-MM-DD HH24:MI:SS') as gds_chg_chck_dtm,
    a.gds_cd,
    b.gds_nm,
    a.gds_chg_req_apv_st_cd,
    b.gds_sell_st_cd,
    a.sell_st_chg_rsn_cntn,
    clas.chg_rsn_str as chgRsnStr,
    clas.detail_yn as detailYn,
    apv.gds_chg_chck_rjct_rsn_cd,
    apv.gds_chg_chck_rjct_rsn_cntn,
    a.cms_lth_gds_apv_obj_yn,
    case
        when a.cms_lth_gds_apv_obj_yn = 'N' then null
        when a.cms_lth_gds_apv_obj_yn = 'Y' and m.bsic_dfrt_rt_apv_st_cd is null then 'WAIT'
        else m.bsic_dfrt_rt_apv_st_cd
    end as bsic_dfrt_rt_apv_st_cd,
    cast(b.gds_dfrt_rt as double precision) as gds_dfrt_rt,
    cast(coalesce(d.mng_std_ctgr_lwst_dfrt_rt,d2.mng_std_ctgr_lwst_dfrt_rt,d3.mng_std_ctgr_lwst_dfrt_rt,d4.mng_std_ctgr_lwst_dfrt_rt,0) as double precision) as mng_std_ctgr_lwst_dfrt_rt,
    cast(coalesce(d.mng_std_ctgr_hgst_dfrt_rt,d2.mng_std_ctgr_hgst_dfrt_rt,d3.mng_std_ctgr_hgst_dfrt_rt,d4.mng_std_ctgr_hgst_dfrt_rt,0) as double precision) as mng_std_ctgr_hgst_dfrt_rt,
    b.gds_pchs_prc,
    b.real_sell_prc,
    b.fval_prc,
    c.csp_cd,
    c.csp_nm,
    d.mgr_md_no,
    f.mgr_id as mdMgrId,
    case when f.mgr_nm is not null then concat(d.mgr_md_no,'/',f.mgr_nm,'/',f.dept_nm) else d.mgr_md_no::text end as mdInfo,
    case
        when apv.gds_chg_chck_mgr_id is not null then
            case when apvMgr.mgr_nm is not null then concat(apvMgr.mgr_nm,'(',apv.gds_chg_chck_mgr_id,')') else apv.gds_chg_chck_mgr_id end
        else
            case when f.mgr_nm is not null then concat(f.mgr_nm,'(',f.mgr_id,')') else d.mgr_md_no::text end
    end as mgrInfo,
    case
        when m.mgr_id is not null then concat(m.mgr_nm,'(',m.mgr_id,')')
        else rtMgr.mgrInfo
    end as rtMgrInfo,
    to_char(to_timestamp(a.gds_chg_req_apv_cncl_dtm,'YYYYMMDDHH24MISS'),'YYYY-MM-DD HH24:MI:SS') as gds_chg_req_apv_cncl_dtm,
    to_char(to_timestamp(a.frst_reg_dtm,'YYYYMMDDHH24MISS'),'YYYY-MM-DD HH24:MI:SS') as frst_reg_dtm,
    a.frst_reg_usr_id,
    a.frst_reg_pgm_id,
    to_char(to_timestamp(a.last_mod_dtm,'YYYYMMDDHH24MISS'),'YYYY-MM-DD HH24:MI:SS') as last_mod_dtm,
    a.last_mod_usr_id,
    a.last_mod_pgm_id
from ez_pd.pd_gds_chg_b a
join ez_pd.pd_gds_c b on a.gds_cd = b.gds_cd
join ez_dp.dp_std_ctgr_b d on b.mng_std_ctgr_cd = d.std_ctgr_cd
join ez_dp.dp_std_ctgr_b d2 on d.high_std_ctgr_cd = d2.std_ctgr_cd
join ez_dp.dp_std_ctgr_b d3 on d2.high_std_ctgr_cd = d3.std_ctgr_cd
join ez_dp.dp_std_ctgr_b d4 on d3.high_std_ctgr_cd = d4.std_ctgr_cd
left join ez_cm.cm_mgr_md_b e on d.mgr_md_no = e.mgr_md_no
left join ez_cm.cm_mgr_b f on e.mgr_id = f.mgr_id
join ez_co.co_csp_b c on b.csp_cd = c.csp_cd
left join ez_pd.pd_gds_chg_req_b r on a.apv_gds_chg_req_no = r.gds_chg_req_no
left join ez_cm.cm_mgr_b reqMgr on r.req_mgr_id = reqMgr.mgr_id
left join ez_pd.pd_gds_chg_chck_b apv on a.apv_gds_chg_chck_no = apv.gds_chg_chck_no
left join ez_cm.cm_mgr_b apvMgr on apv.gds_chg_chck_mgr_id = apvMgr.mgr_id
left join ez_pd.pd_cms_lth_gds_apv_l m on a.gds_chg_no = m.gds_chg_no
left join lateral (
    select
        case
            when (array_agg(ccd.gds_chg_clas_cd order by ccd.gds_chg_clas_seq))[1] = 'AP01' then '신규'
            when (array_agg(ccd.gds_chg_clas_cd order by ccd.gds_chg_clas_seq))[1] in ('AP08','AP09','AP10','AP11') then '판매상태변경'
            else '수정'
        end as clas_type_nm,
        string_agg(distinct cm.comm_dtl_cd_nm,', ') as chg_rsn_str,
        case
            when bool_or(ccd.gds_chg_clas_cd in ('AP02','AP03','AP04','AP10')) then 'Y'
            else 'N'
        end as detail_yn
    from ez_pd.pd_gds_chg_clas_d ccd
    left join ez_cm.cm_comm_dtl_c cm on ccd.gds_chg_clas_cd = cm.comm_dtl_cd and cm.comm_cd = 'gds_chg_clas_cd'
    where ccd.gds_chg_chck_typ_cd = 'APV'
    and ccd.gds_chg_no = a.gds_chg_no
) clas on true
left join (
    select
        md1.mgr_md_no,
        cast(string_agg(mgr1.mgr_nm||'('||mgr1.mgr_id||')',',' order by mgr1.mgr_nm) as text) as mgrInfo
    from ez_cm.cm_mgr_md_d md1
    join ez_cm.cm_mgr_b mgr1 on md1.bsic_dfrt_rt_apv_mgr_id = mgr1.mgr_id
    group by md1.mgr_md_no
) rtMgr on rtMgr.mgr_md_no = e.mgr_md_no
where a.gds_chg_req_apv_st_cd = 'REQS'
and d.mgr_md_no = 33
order by a.gds_chg_no desc
limit 100 offset 100;