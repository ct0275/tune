select sum(case when dlv.dlv_st_cd = 'INSR_STBY' or sndg.ord_snd_st_cd = '00' then 1 else 0 end) as giftordercnt,
	sum(case when dlv.dlv_st_cd = 'STBY' or sndg.ord_snd_st_cd = '01' then 1 else 0 end) as stbycnt,
	sum(case when dlv.dlv_st_cd = 'RDY' or sndg.ord_snd_st_cd = '06' then 1 else 0 end) as rdycnt,
	sum(case when dlv.dlv_st_cd = 'DLV' then 1 else 0 end) as dlvcnt,
	sum(case when dlv.dlv_st_cd = 'CMPT' or sndg.ord_snd_st_cd = '0' then 1 else 0 end) as cmptcnt
from ez_or.or_ord_b ord
	left outer join ez_or.dl_dlv_b dlv on dlv.ord_no = ord.ord_no and dlv.dlv_obnd_typ_cd = 'ORD'
	left outer join ez_or.dl_ord_snd_gds_d sndg on sndg.ord_no = ord.ord_no and sndg.ord_snd_st_cd not in('03','07','09')
where ord.ord_dtm between to_char(CURRENT_DATE - INTERVAL '3 DAYS', 'YYYYMMDD') || '000000' and to_char(CURRENT_DATE, 'YYYYMMDD') || '595959';