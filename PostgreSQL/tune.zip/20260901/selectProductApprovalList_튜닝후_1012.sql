/* com.ezwelesp.bo.hims.product.rest.approval.mapper.query.HimsProductApprovalQueryMapper.selectProductApprovalList */
EXPLAIN (ANALYZE, BUFFERS)
WITH target_products AS MATERIALIZED (
    SELECT p.gds_cd
    FROM ez_dp.dp_std_ctgr_b d
    CROSS JOIN LATERAL (
        SELECT b.gds_cd
        FROM ez_pd.pd_gds_c b
        WHERE b.mng_std_ctgr_cd = d.std_ctgr_cd
        OFFSET 0
    ) p
    WHERE d.mgr_md_no = 33
),
reqs AS MATERIALIZED (
    SELECT
        a.gds_chg_no,
        a.gds_cd
    FROM ez_pd.pd_gds_chg_b a
    WHERE a.gds_chg_req_apv_st_cd = 'REQS'
),
target_changes AS MATERIALIZED (
    SELECT
        r.gds_chg_no,
        r.gds_cd
    FROM reqs r
    JOIN target_products p
      ON p.gds_cd = r.gds_cd
),
paged_changes AS MATERIALIZED (
    SELECT tc.gds_chg_no
    FROM target_changes tc
    CROSS JOIN LATERAL (
        SELECT
            b.gds_cd,
            b.mng_std_ctgr_cd,
            b.csp_cd
        FROM ez_pd.pd_gds_c b
        WHERE b.gds_cd = tc.gds_cd
        OFFSET 0
    ) b
    JOIN ez_dp.dp_std_ctgr_b d
      ON b.mng_std_ctgr_cd = d.std_ctgr_cd
    JOIN ez_dp.dp_std_ctgr_b d2
      ON d.high_std_ctgr_cd = d2.std_ctgr_cd
    JOIN ez_dp.dp_std_ctgr_b d3
      ON d2.high_std_ctgr_cd = d3.std_ctgr_cd
    JOIN ez_dp.dp_std_ctgr_b d4
      ON d3.high_std_ctgr_cd = d4.std_ctgr_cd
    JOIN ez_co.co_csp_b c
      ON b.csp_cd = c.csp_cd
    WHERE d.mgr_md_no = 33
    ORDER BY tc.gds_chg_no DESC
    LIMIT 100 OFFSET 100
)
SELECT
    a.gds_chg_no,
    (
        SELECT DISTINCT ON (gds_chg_no)
            CASE
                WHEN gds_chg_clas_cd = 'AP01' THEN '신규'
                WHEN gds_chg_clas_cd IN ('AP08', 'AP09', 'AP10', 'AP11')
                    THEN '판매상태변경'
                ELSE '수정'
            END AS clasTypeNm
        FROM ez_pd.pd_gds_chg_clas_d
        WHERE gds_chg_chck_typ_cd = 'APV'
          AND gds_chg_no = a.gds_chg_no
        ORDER BY gds_chg_no, gds_chg_clas_seq
    ) AS clasTypeNm,

    to_char(
        to_timestamp(r.gds_chg_chck_req_dtm, 'YYYYMMDDHH24MISS'),
        'YYYY-MM-DD HH24:MI:SS'
    ) AS gds_chg_chck_req_dtm,  /*승인요청일시*/
    r.gds_chg_req_rsn_cntn,
    r.req_mgr_id,
    CASE
        WHEN reqMgr.mgr_nm IS NOT NULL
            THEN concat(reqMgr.mgr_nm, '(', r.req_mgr_id, ')')
        ELSE r.req_mgr_id
    END AS reqMgrInfo,

    to_char(
        to_timestamp(apv.gds_chg_chck_dtm, 'YYYYMMDDHH24MISS'),
        'YYYY-MM-DD HH24:MI:SS'
    ) AS gds_chg_chck_dtm,  /*승인완료일시*/
    a.gds_cd,
    b.gds_nm,
    a.gds_chg_req_apv_st_cd, /*해당건승인상태*/
    b.gds_sell_st_cd, /*상품마스터판매상태*/
    a.sell_st_chg_rsn_cntn, /*판매상태변경사유 - 판매중지로 판매상태가 변경된경우 사유가 있음(위해상품 )*/

    (
        SELECT string_agg(t.comm_dtl_cd_nm, ', ')
        FROM (
            SELECT cm.comm_dtl_cd_nm
            FROM ez_pd.pd_gds_chg_clas_d ccd
            JOIN ez_cm.cm_comm_dtl_c cm
              ON ccd.gds_chg_clas_cd = cm.comm_dtl_cd
             AND cm.comm_cd = 'gds_chg_clas_cd'
            WHERE ccd.gds_chg_chck_typ_cd = 'APV'
              AND ccd.gds_chg_no = a.gds_chg_no
            GROUP BY ccd.gds_chg_clas_cd, cm.comm_dtl_cd_nm
        ) t
    ) AS chgRsnStr,

    (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM ez_pd.pd_gds_chg_clas_d
                WHERE gds_chg_clas_cd IN ('AP02', 'AP03', 'AP04', 'AP10')
                  AND gds_chg_no = a.gds_chg_no
            ) THEN 'Y'
            ELSE 'N'
        END
    ) AS detailYn,

    apv.gds_chg_chck_rjct_rsn_cd, /*승인반려사유코드*/
    apv.gds_chg_chck_rjct_rsn_cntn, /*승인반려사유*/
    a.cms_lth_gds_apv_obj_yn, /*기준수익률승인대상*/

    CASE
        WHEN a.cms_lth_gds_apv_obj_yn = 'N' THEN NULL
        WHEN a.cms_lth_gds_apv_obj_yn = 'Y'
         AND m.bsic_dfrt_rt_apv_st_cd IS NULL THEN 'WAIT'
        ELSE m.bsic_dfrt_rt_apv_st_cd
    END AS bsic_dfrt_rt_apv_st_cd, /*기준수익률 승인상태*/

    CAST(b.gds_dfrt_rt AS double precision) AS gds_dfrt_rt, /*상품 마스터 수익률*/

    CAST(COALESCE(
        d.mng_std_ctgr_lwst_dfrt_rt,
        d2.mng_std_ctgr_lwst_dfrt_rt,
        d3.mng_std_ctgr_lwst_dfrt_rt,
        d4.mng_std_ctgr_lwst_dfrt_rt,
        0
    ) AS double precision) AS mng_std_ctgr_lwst_dfrt_rt, /*카테고리 최저기준수익률*/

    CAST(COALESCE(
        d.mng_std_ctgr_hgst_dfrt_rt,
        d2.mng_std_ctgr_hgst_dfrt_rt,
        d3.mng_std_ctgr_hgst_dfrt_rt,
        d4.mng_std_ctgr_hgst_dfrt_rt,
        0
    ) AS double precision) AS mng_std_ctgr_hgst_dfrt_rt, /*카테고리 최고기준수익률*/

    b.gds_pchs_prc, /*상품 마스터 매입가격*/
    b.real_sell_prc, /*상품 마스터 판매가격*/
    b.fval_prc, /*상품 마스터 액면가격*/
    c.csp_cd,
    c.csp_nm,
    d.mgr_md_no,
    f.mgr_id AS mdMgrId,

    CASE
        WHEN f.mgr_nm IS NOT NULL
            THEN concat(d.mgr_md_no, '/', f.mgr_nm, '/', f.dept_nm)
        ELSE d.mgr_md_no::text
    END AS mdInfo,

    CASE
        WHEN apv.gds_chg_chck_mgr_id IS NOT NULL THEN
            CASE
                WHEN apvMgr.mgr_nm IS NOT NULL
                    THEN concat(apvMgr.mgr_nm, '(', apv.gds_chg_chck_mgr_id, ')')
                ELSE apv.gds_chg_chck_mgr_id
            END /*처리시 완료한담당자정보*/
        ELSE
            CASE
                WHEN f.mgr_nm IS NOT NULL
                    THEN concat(f.mgr_nm, '(', f.mgr_id, ')')
                ELSE d.mgr_md_no::text
            END /*승인전일때는 승인담당자정보(MD)*/
    END AS mgrInfo,

    CASE
        WHEN m.mgr_id IS NOT NULL
            THEN concat(m.mgr_nm, '(', m.mgr_id, ')') /*처리완료시 완료한담당자정보*/
        ELSE rtMgr.mgrInfo /*처리전일때는 해당 MD의 기준수익률담당자정보*/
    END AS rtMgrInfo,

    to_char(
        to_timestamp(a.gds_chg_req_apv_cncl_dtm, 'YYYYMMDDHH24MISS'),
        'YYYY-MM-DD HH24:MI:SS'
    ) AS gds_chg_req_apv_cncl_dtm,

    to_char(
        to_timestamp(a.frst_reg_dtm, 'YYYYMMDDHH24MISS'),
        'YYYY-MM-DD HH24:MI:SS'
    ) AS frst_reg_dtm,
    a.frst_reg_usr_id,
    a.frst_reg_pgm_id,

    to_char(
        to_timestamp(a.last_mod_dtm, 'YYYYMMDDHH24MISS'),
        'YYYY-MM-DD HH24:MI:SS'
    ) AS last_mod_dtm,
    a.last_mod_usr_id,
    a.last_mod_pgm_id

FROM paged_changes pc
JOIN ez_pd.pd_gds_chg_b a
  ON a.gds_chg_no = pc.gds_chg_no
JOIN ez_pd.pd_gds_c b
  ON a.gds_cd = b.gds_cd
JOIN ez_dp.dp_std_ctgr_b d
  ON b.mng_std_ctgr_cd = d.std_ctgr_cd
JOIN ez_dp.dp_std_ctgr_b d2
  ON d.high_std_ctgr_cd = d2.std_ctgr_cd
JOIN ez_dp.dp_std_ctgr_b d3
  ON d2.high_std_ctgr_cd = d3.std_ctgr_cd
JOIN ez_dp.dp_std_ctgr_b d4
  ON d3.high_std_ctgr_cd = d4.std_ctgr_cd
LEFT JOIN ez_cm.cm_mgr_md_b e
  ON d.mgr_md_no = e.mgr_md_no
LEFT JOIN ez_cm.cm_mgr_b f
  ON e.mgr_id = f.mgr_id
JOIN ez_co.co_csp_b c
  ON b.csp_cd = c.csp_cd

LEFT JOIN ez_pd.pd_gds_chg_req_b r
  ON a.apv_gds_chg_req_no = r.gds_chg_req_no
LEFT JOIN ez_cm.cm_mgr_b reqMgr
  ON r.req_mgr_id = reqMgr.mgr_id

LEFT JOIN ez_pd.pd_gds_chg_chck_b apv
  ON a.apv_gds_chg_chck_no = apv.gds_chg_chck_no
LEFT JOIN ez_cm.cm_mgr_b apvMgr
  ON apv.gds_chg_chck_mgr_id = apvMgr.mgr_id
LEFT JOIN ez_pd.pd_cms_lth_gds_apv_l m
  ON a.gds_chg_no = m.gds_chg_no

LEFT JOIN (
    SELECT
        md1.mgr_md_no,
        CAST(
            string_agg(
                mgr1.mgr_nm || '(' || mgr1.mgr_id || ')',
                ',' ORDER BY mgr1.mgr_nm
            ) AS text
        ) AS mgrInfo
    FROM ez_cm.cm_mgr_md_d md1
    JOIN ez_cm.cm_mgr_b mgr1
      ON md1.bsic_dfrt_rt_apv_mgr_id = mgr1.mgr_id
    GROUP BY md1.mgr_md_no
) rtMgr
  ON rtMgr.mgr_md_no = e.mgr_md_no

WHERE a.gds_chg_req_apv_st_cd = 'REQS'
  AND d.mgr_md_no = 33

ORDER BY a.gds_chg_no DESC;