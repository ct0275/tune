/*
 hims > 법인숙박관리 > 사계절휴양소(현대차) 신청관리 > 신청목록
 
 고객사명 = hmc로 조회 후, (+ 기타 검색 조건 설정)
 결과 목록에서 각 신청상태값 선택 시, 아래의 쿼리가 실행됨
 
 툴에서 최초 1회 실행 시, 7초, 
 다시 실행 시에는 평균적으로 4초가량 소요됨
 * */
/* com.ezwelesp.bo.hims.customer.rest.lodgement.checkin.custom.hmc.order.applylist.mapper.query.HmcHimsOrderApplyListQueryMapper.selectApplyList */
SELECT '2221112$ezadmin' AS uid
         , a.ord_dt				/* 신청일자(주문일) */
         , b.clnt_nm            /* 고객사명 */
         , d.clnt_empno         /* 사번 */
         , COALESCE((select comm_dtl_cd_nm   /* 공통상세코드명 */
	                from ez_ct.ct_cc_dtl_c
	                where clnt_cd = a.clnt_cd
	                and cc_cd   /* 고객사공통코드 */ = '1102'
	                and cc_dtl_cd   /* 고객사공통상세코드 */ = d.cc_dept_cd), '-') AS ccBrNm     /* 소속1 */
	    , (
			 SELECT ccdc.comm_dtl_cd_nm
			 FROM ez_ct.ct_cc_dtl_c ccdc
			 WHERE ccdc.clnt_cd = d.clnt_cd
				AND ccdc.cc_cd = '1104'
				AND ccdc.cc_dtl_cd = d.cc_jgrd_cd
         ) as cc_jgrd_nm /* 직급 */
         , a.aplr_nm            /* 성명 */
         , a.user_key			/* 유저키 */
         , a.ldg_ord_rsv_st_cd	/* 상태(숙박주문 예약상태코드) */
         , a.ldg_grp_cd			/* 숙박그룹코드 */
         , c.accm_nm            /* 시설명 */
         , c.accm_br_nm         /* 지점명 */
         , c.accm_br_cd         /* 지점코드 */
         , c.room_nm            /* 객실명 */
         , c.room_pytp_cntn     /* 평형 */
         , a.room_cnt           /* 객실수 */
         , a.ckin_Dt			/* 체크인 */
         , a.ckou_Dt			/* 체크아웃 */
         , a.tyr_use_sbtr_scor  /* 박수 */
         , a.ord_no             /* 신청번호 */
         , a.ldg_rsv_no         /* 예약번호 */
         , a.seas_div_cd        /* 시즌정보 */
         , a.ldg_clnt_rgm_no    /* 숙박고객사제도번호 */
         , a.ldg_ord_afe_nos    /* 숙박주문지원차수 */
         , a.ldg_pksn_plcy_no   /* 회차 */
         , a.ldg_ord_apl_nos    /* 차수 */
         , a.acss_dvc_cd        /* 신청경로 */
         , a.pymt_amt           /* 금액 */
         , a.frst_reg_usr_id AS regUsrNm           /* 등록자 */
         , a.frst_reg_dtm       /* 등록일시 */
         , a.last_mod_usr_id AS modUsrNm           /* 수정자 */
         , a.last_mod_dtm       /* 수정일시 */
         , CASE WHEN (A.seas_div_cd = '1002' AND a.ldg_ord_apl_nos = '1') THEN 'LOTTERY' ELSE 'FIRST_COME' END AS applicationType
         , AAC.accm_typ_cd		/*시설유형 */
         , a.cc_ldg_ord_typ_cd /*신청구분 */
         , a.ldg_lttr_scor		/*추첨점수*/
         , a.ldg_ord_win_yn
         , a.aplr_mbl_telno
         , CASE WHEN a.pymt_cmpt_dt IS NULL OR a.pymt_cmpt_dt = '' THEN 'N'
            ELSE 'Y'
            END as pymtCmptYn /* 결제여부 */
         , (a.ckou_dt::date - a.ckin_dt::date)::numeric as useDay /* 박수 */
         , a.hndw_rsv_yn			/*수기예약 여부*/
         , a.mgr_prcs_memo			/*관리자처리메모*/
         , claim.clm_no             /* 클레임번호 */
         , a.aplr_eml_adr			/*신청자 이메일 주소*/
    FROM ez_or.or_ldg_ord_b a
    INNER JOIN ez_ct.ct_clnt_b b
        ON a.clnt_cd = b.clnt_cd
    LEFT OUTER JOIN (             
        SELECT aac.accm_cd
             , aac.accm_nm
             , aabc.accm_br_area_cd
             , aabc.accm_br_cd
             , aabc.accm_br_nm
             , aabc.csp_cd
             , ccb.csp_nm
             , aard.room_cd
             , aard.room_nm
             , aard.room_pytp_cntn
             , aard.use_yn             as room_use_yn
             , aard.stay_bsic_psnl_cnt      /*투숙기준인원수*/
             , aard.stay_poss_max_psnl_cnt  /*투숙가능최대인원수*/
        FROM ez_pd.ad_accm_c aac
        INNER JOIN ez_pd.ad_accm_br_c aabc
            ON aac.accm_cd = aabc.accm_cd
        INNER JOIN ez_pd.ad_accm_br_room_r aabrr
            ON aabc.accm_br_cd = aabrr.accm_br_cd
        INNER JOIN ez_pd.ad_accm_room_d aard
            ON aabrr.room_cd = aard.room_cd
        LEFT OUTER JOIN ez_co.co_csp_b ccb
            ON aard.csp_cd = ccb.csp_cd
        WHERE aard.accm_apv_st_cd = 'COMP'
     
        )c
            ON a.accm_br_cd = c.accm_br_cd
            AND a.room_cd = c.room_cd
        LEFT OUTER JOIN (
             
        SELECT mgr_lgin_id
             , mgr_nm
             , hifi_dept_cd
             , dept_nm          /* 부서명 */
             , eml_adr
             , telno
             , mbl_telno
             , mgr_st_cd
        FROM ez_cm.cm_mgr_b
     
        ) cus
		ON a.user_key = cus.mgr_lgin_id
        LEFT OUTER JOIN (
            /* include com.ezwelesp.bo.hims.customer.rest.lodgement.checkin.order.common.mapper.query.HimsOrderCommonQueryMapper.userInfo, 쿼리 성능 이슈로 변경 */
            SELECT a.clnt_empno /*사번*/
                , a.clnt_cd
                , a.user_key
                , (SELECT comm_dtl_cd_nm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = a.clnt_cd AND cc_cd = '1101' AND cc_dtl_cd = a.cc_br_cd ) AS ccBrNm /*소속*/
                , a.cc_dept_cd
                , a.usr_nm
                , a.cc_part_cd
                , a.cc_team_cd
                , a.cc_jgrd_cd
            FROM (
                SELECT
                    upd.clnt_empno /*사번*/
                    , upd.usr_nm
                    , ub.cc_part_cd
                    , ub.cc_team_cd
                    , ub.clnt_cd
                    , ub.user_key
                    , ub.cc_br_cd
                    , ub.cc_dept_cd
                    , ub.cc_jgrd_cd
                FROM  ez_ct.ct_usr_b ub
                LEFT JOIN ez_pi.pi_usr_pi_d upd ON ub.user_key = upd.user_key
                WHERE ub.clnt_cd != 'polbokji'
            ) a /*사용자기본*/
            WHERE a.clnt_cd = 'hmc'
        ) d
        ON a.user_key = d.user_key
        LEFT OUTER JOIN EZ_PD.AD_ACCM_BR_C BC /* 숙박시설지점코드 */ /* 추가 */
	    	ON A.ACCM_BR_CD = BC.ACCM_BR_CD 
	    LEFT OUTER JOIN EZ_PD.AD_ACCM_C AAC /* 숙박시설코드 */ /* 추가 */
	   		ON BC.ACCM_CD = AAC.ACCM_CD
	   	LEFT OUTER JOIN (
            SELECT ord_no
                 , string_agg(ccb.clm_no , ',') as clm_no
            FROM ez_or.cl_clm_b ccb
            GROUP BY ccb.ord_no
        )claim
            ON claim.ord_no = a.ord_no /* 클레임 조회 */         
         WHERE  a.ldg_clnt_rgm_no = 1716 /*고객사제도번호*/
                AND a.ldg_grp_cd = '1001'  /*숙박그룹코드*/            
                AND a.ldg_ord_rsv_st_cd = '1002'  /*숙박주문예약상태코드*/ 
                
                /* 아래의 주석 처리한 쿼리는 화면 상의 검색조건에 추가될 수도 있어서 참고용 */
--                AND a.user_key = #{userKey} /*유저키*/
--                AND a.ldg_ord_rsv_st_cd = #{ldgOrdRsvStCd}  /*숙박주문예약상태코드*/
--                AND a.aplr_telno = #{aplrTelno} /*연락처*/
--                AND a.aplr_mbl_telno IN (#{tel})
--                AND a.mgr_prcs_memo LIKE CONCAT('%', #{mgrPrcsMemo}, '%')  /* 처리담당자 메모 */
--                AND c.accm_cd = #{accmCd} /*시설명*/
--                AND c.accm_br_cd = #{accmBrCd} /*지점명*/
--                AND c.room_cd = #{roomCd} /*객실명*/
--                AND a.ord_no = #{ordNo} /* 신청번호 */
--                AND a.ldg_rsv_no = #{ldgRsvNo} /* 예약번호 */
--                AND a.acss_dvc_cd = #{acssDvcCd} /* 신청경로 */
--                AND a.ldg_pksn_plcy_no = #{ldgPksnPlcyNo} /* 성수기 회차 */
--                AND a.ldg_ord_win_yn = #{ldgOrdWinYn} /* 당첨여부 */
--        		/* 선착순 S */
--    			and a.seas_div_cd = '1001'
--    			and a.ldg_ord_apl_nos = '1'
--    			/* 선착순 E */
--				/* 추첨 S */
--    			and a.seas_div_cd = '1002'
--    			and a.ldg_ord_apl_nos = '1'
--    			/* 추첨 E */
--            	and a.cc_ldg_ord_typ_cd = #{ccLdgOrdTypCd}  /* 신청구분 */ 
--            	and AAC.accm_typ_cd = #{accmTypCd}	 /* 시설유형 */ 
--					and a.acss_dvc_cd IN ('PCWB')
--					 and a.acss_dvc_cd IN ('MWEB', 'MAPP')
--					and a.hndw_rsv_yn = 'Y' 
                
        and a.ldg_ord_rsv_st_cd != '1000'
        order by a.frst_reg_dtm DESC, a.ord_no DESC LIMIT 100
;        