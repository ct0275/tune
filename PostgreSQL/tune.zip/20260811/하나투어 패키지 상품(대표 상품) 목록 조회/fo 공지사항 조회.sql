/* com.ezwelesp.fo.customer.rest.indivudualboard.mapper.query.IndivudualBoardAnncQueryMapper.selectAnncPostNav */
WITH annc AS(
    SELECT
        b.annc_no,
        CAST(lag (b.annc_no) over (ORDER BY b.frst_reg_dtm DESC) AS text) AS next_annc_no,
        lag (b.annc_ttl) over (ORDER BY b.frst_reg_dtm DESC) AS next_annc_ttl,
        CAST(lead (b.annc_no) over (ORDER BY b.frst_reg_dtm DESC) AS text) AS prev_annc_no,
        lead (b.annc_ttl) over (ORDER BY b.frst_reg_dtm DESC) AS prev_annc_ttl
    FROM ez_cm.bb_annc_b b
    LEFT JOIN ez_dp.dp_clnt_aply_stup_b stupb ON b.clnt_csp_aply_no = stupb.clnt_aply_stup_no
    WHERE b.sys_knd_cd = 'HEZO'
        AND b.annc_sys_dtl_knd_cd = 'FOCS'
        AND b.use_yn = 'Y'
         
     
     
        AND b.mbl_exps_yn = 'Y'
     
 
         
    AND CASE WHEN ( b.clnt_cd IS NOT NULL AND b.clnt_cd != '' ) THEN
        b.clnt_cd = 'thehandsome'
    WHEN stupb.clnt_aply_stup_cd = 'APLY_EXCLD' THEN
    EXISTS(
    SELECT 1
    FROM ez_dp.dp_clnt_aply_stup_clnt_r stupr
    WHERE stupr.clnt_cd = 'thehandsome'
    AND stupr.clnt_aply_stup_no = stupb.clnt_aply_stup_no
    AND stupr.clnt_stup_aply_yn = 'Y'
    )
    ELSE
    NOT EXISTS(
    SELECT 1
    FROM ez_dp.dp_clnt_aply_stup_clnt_r stupr
    WHERE stupr.clnt_cd = 'thehandsome'
    AND stupr.clnt_aply_stup_no = stupb.clnt_aply_stup_no
    AND stupr.clnt_stup_aply_yn = 'N'
    )
    END
 
    )
    SELECT
        ac.next_annc_no,
        ac.next_annc_ttl,
        ac.prev_annc_no,
        ac.prev_annc_ttl
    FROM annc ac
    WHERE annc_no = 3014192