/* com.ezwelesp.fo.customer.rest.indivudualboard.mapper.query.IndivudualBoardAnncQueryMapper.selectAnncTab */
SELECT
        c.comm_cd ,
        c.comm_dtl_cd ,
        CASE WHEN c.comm_dtl_cd = 'CNM' then
        (SELECT ccb.clnt_nm FROM ez_ct.ct_clnt_b ccb WHERE ccb.clnt_cd = 's-oil')
    ELSE c.comm_dtl_cd_nm END AS comm_dtl_cd_nm,
    c.comm_dtl_cd_desc ,
    c.high_comm_dtl_cd
    FROM
    ez_cm.cm_comm_dtl_c c
        LEFT JOIN (
            SELECT
                b.annc_typ_cd,
                COUNT(b.annc_typ_cd) AS cnt
                FROM
                ez_cm.bb_annc_b b
            LEFT JOIN ez_dp.dp_clnt_aply_stup_b stupb
            ON b.clnt_csp_aply_no = stupb.clnt_aply_stup_no
            WHERE b.sys_knd_cd = 'HEZO'
            AND b.annc_sys_dtl_knd_cd = 'FOCS'
            AND b.use_yn = 'Y'
             
     
     
        AND b.mbl_exps_yn = 'Y'
     
 
             
    AND CASE WHEN ( b.clnt_cd IS NOT NULL AND b.clnt_cd != '' ) THEN
        b.clnt_cd = 's-oil'
    WHEN stupb.clnt_aply_stup_cd = 'APLY_EXCLD' THEN
    EXISTS(
    SELECT 1
    FROM ez_dp.dp_clnt_aply_stup_clnt_r stupr
    WHERE stupr.clnt_cd = 's-oil'
    AND stupr.clnt_aply_stup_no = stupb.clnt_aply_stup_no
    AND stupr.clnt_stup_aply_yn = 'Y'
    )
    ELSE
    NOT EXISTS(
    SELECT 1
    FROM ez_dp.dp_clnt_aply_stup_clnt_r stupr
    WHERE stupr.clnt_cd = 's-oil'
    AND stupr.clnt_aply_stup_no = stupb.clnt_aply_stup_no
    AND stupr.clnt_stup_aply_yn = 'N'
    )
    END
 
            GROUP BY b.annc_typ_cd
        ) annc
    ON c.comm_dtl_cd = annc.annc_typ_cd
    WHERE
    c.comm_cd = 'annc_typ_cd'
    AND c.high_comm_dtl_cd = 'FOCS'
    AND c.use_yn = 'Y'
    AND annc.cnt > 0
    ORDER BY c.sort_ordg ASC;