/* com.ezwelesp.fo.product.rest.display.life.tour.hanatour.mapper.query.DisplayLifeTourHanatourQueryMapper.selectHanaTourRepTripList */
SELECT
               REP.rps_trip_gds_cd
             , REP.rps_trip_gds_div_nm
             , REP.rps_trip_gds_nm
             , REP.rps_trip_gds_scwd
             , REP.rps_trip_gds_cntn
             , REP.sell_strt_dt
             , REP.sell_end_dt
             , REP.trip_gds_dsp_lwpr_bsic_dt
             , REP.trip_gds_dsp_lwst_prc
             , REP.trip_gds_dsp_hgst_prc
             , REP.trip_gds_sell_st_cd
             , REP.trip_gds_dome_abrd_div_cd
             , REP.trip_cnry_cd
             , REP.trip_cnry_nm
             , REP.trip_city_cd
             , REP.trip_city_nm
             , REP.gds_rps_img_url
             , REP.gds_rps_img_url
             , REP.trip_ldg_cnt
             , REP.trip_dcnt
             , REP.free_schd_trip_gds_yn
             , REP.trip_gds_shpg_cnt
         
        FROM ez_pd.pd_trip_gds_rps_gds_b REP
        WHERE 1 = 1
          AND REP.use_yn = 'Y'
          AND REP.sell_end_dt >= TO_CHAR(NOW(), 'YYYYMMDD')
         
         
         
              /* 도시코드 검색 */
                AND EXISTS (
                    SELECT REP.rps_trip_gds_cd
                    FROM (
                        SELECT REP.rps_trip_gds_cd
                        FROM ez_pd.pd_trip_gds_rps_gds_b REP
                        WHERE REP.use_yn = 'Y' AND REP.trip_city_cd IN
                         (  
                            'DPS'
                         ) 
                        UNION ALL
                        SELECT DEST.rps_trip_gds_cd
                        FROM ez_pd.pd_trip_gds_rps_gds_thrgh_r DEST
                        WHERE DEST.trip_city_cd IN
                         (  
                            'DPS'
                         ) 
                        UNION ALL
                        SELECT SALE.rps_trip_gds_cd
                        FROM ez_pd.pd_trip_gds_sell_gds_b SALE
                        WHERE SALE.use_yn = 'Y' AND SALE.arvl_trip_city_cd IN
                         (  
                            'DPS'
                         ) 
                        ) SUB
                    WHERE SUB.rps_trip_gds_cd = REP.rps_trip_gds_cd
                )
             
         
         
         

         

         
         
         
         
        AND EXISTS (
        SELECT 1
        FROM ez_pd.pd_trip_gds_sell_gds_b SALE
        JOIN ez_pd.pd_trip_gds_prc_d PRICE ON SALE.sell_trip_gds_cd = PRICE.sell_trip_gds_cd
         AND PRICE.trip_gds_age_div_cd ='A'
        WHERE SALE.rps_trip_gds_cd = REP.rps_trip_gds_cd
          AND SALE.use_yn = 'Y'
          /* 출발일 검색 */
            AND SALE.dptr_dt   >=   '20261227'
             
             
                AND SALE.dptr_dt    <=   '20261230'
             
         
         
         
         
         
         
         
         
        )
     
        ORDER BY REP.trip_gds_dsp_lwst_prc LIMIT 10 OFFSET 10