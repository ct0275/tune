 /* CscoMap.getClientPushSend */
        <include refid="CommonMap.preparePaging_fragment" />
        SELECT *
          FROM (
                  SELECT CPB.PUSH_SEQ AS MSG_SEQ
                     , TO_CHAR(AM.SEND_SDATE,'YYYYMMDDHH24MISS') AS SEND_DT
                     , CPB.MSG_TTL AS MSG_TTL
                     , CPB.MSG_CNTN AS SEND_MSG
                     , CPSOD.CLNT_CD AS CLIENT_CD
                     , CPB.MBL_OS_DIV_CD AS OS_TYPE
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'push_infm_typ_cd' AND COMM_DTL_CD = CPB.PUSH_INFM_TYP_CD) AS INFM_TYPE_NM
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'push_snd_shap_cd' AND COMM_DTL_CD = CPB.PUSH_SND_SHAP_CD) AS SND_SHAP_NM
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'mbl_os_div_cd' AND COMM_DTL_CD = CPB.MBL_OS_DIV_CD) AS OS_TYPE_NM
                     , CASE
                     	WHEN AM.FPSTEP = 'C' THEN '발송완료'
				        WHEN AM.FPSTEP = 'R' THEN '발송대기'
				        WHEN AM.FPSTEP = 'S' THEN '발송중'
				        WHEN (AM.FPSTEP = 'T' OR AM.FPSTEP = 'F') THEN '실패'
				        ELSE ''
				       END AS MSG_SND_ST_NM
                     , CPB.IMG_FILE_NM AS IMG_TITLE
                     , CPB.IMG_FILE_PATH AS IMG_FILE_PATH
                  FROM EZ_CM.CM_PUSH_B CPB
                 INNER JOIN (
                 	SELECT PUSH_SEQ, PUSH_TRMS_SEQ, CLNT_CD, USER_KEY
                 	FROM EZ_CM.CM_PUSH_SND_OBJ_D
                 	WHERE CLNT_CD = #{client_cd}
                 	) CPSOD ON CPB.PUSH_SEQ = CPSOD.PUSH_SEQ
				 INNER JOIN EZ_FPUSH.AGPUSH_MASTER AM
					ON CPSOD.PUSH_TRMS_SEQ = AM.SERIALNUM
                 WHERE CPB.DEL_YN = 'N'
                 	AND AM.SEND_SDATE BETWEEN TO_TIMESTAMP(#{stt_dt} || '000000','YYYYMMDDHH24MISS') AND TO_TIMESTAMP(#{end_dt} || '235959', 'YYYYMMDDHH24MISS')
                 <if test="user_key != null and user_key != ''">
                      AND CPSOD.USER_KEY = #{user_key}
                 </if>
                 <if test="infm_type != null and infm_type != ''">
                      AND CPB.PUSH_INFM_TYP_CD = #{infm_type}
                 </if>
                 <if test="snd_shap != null and snd_shap != ''">
                      AND CPB.PUSH_SND_SHAP_CD = #{snd_shap}
                 </if>
               )
               <where>
                 <if test="sch_txt != null and sch_txt != ''">
                   AND (MSG_TTL LIKE '%' || #{sch_txt} || '%' OR SEND_MSG LIKE '%' || #{sch_txt} || '%')
                 </if>
               </where>
        <include refid="CommonMap.finalizePaging_fragment"/>