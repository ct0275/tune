/* com.ezwelesp.bo.hcas.customer.rest.employee.mapper.query.HcasMemberQueryMapper.selectBoardMemberAndEmployeeList */
SELECT /* 임직원 목록 조회(HIMS) HcasMemberQueryMapper.selectBoardMemberAndEmployeeList */
       ub.clnt_cd AS clntCd,
       cb.clnt_nm AS clntNm,
       ub.user_key AS userKey,
       ub.usr_nm AS usrNm,
       ub.self_crtf_bymd_dt AS selfCrtfBymdDt,
       ub.self_crtf_gndr_nval AS selfCrtfGndrNval,
       CONCAT(ub.self_crtf_bymd_dt, '-', ub.self_crtf_gndr_nval) AS bymdg,
       ub.usr_id AS usrId,
       ub.clnt_empno AS clntEmpno,
       ub.cc_hlof_st_cd AS ccHlofStCd,
       COALESCE(
           (
               SELECT comm_dtl_cd_nm
               FROM ez_ct.ct_cc_dtl_c c
               WHERE c.clnt_cd = ub.clnt_cd
                 AND cc_cd = '1401'
                 AND cc_dtl_cd = ub.cc_hlof_st_cd
           ),
           ''
       ) AS ccHlofStNm,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1401'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_hlof_st_cd
       ) AS ccHlofStNm,
       ub.use_yn AS useYn,
       ub.epm_shap_cd AS epmShapCd,
       cdc.lgin_poss_yn AS lginPossYn,
       cdc.wfp_use_poss_yn AS wfpUsePossYn,
       cdc.spp_use_poss_yn AS sppUsePossYn,
       ub.self_crtf_yn AS selfCrtfYn,
       ub.cc_br_cd AS ccBrCd,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1101'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_br_cd
       ) AS ccBrNm,
       ub.cc_dept_cd AS ccDeptCd,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1102'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_dept_cd
       ) AS ccDeptNm,
       ub.cc_team_cd AS ccTeamCd,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1103'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_team_cd
       ) AS ccTeamNm,
       ub.cc_part_cd AS ccPartCd,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1107'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_part_cd
       ) AS ccPartNm,
       ub.cc_jgrd_cd AS ccJgrdCd,
       (
           SELECT comm_dtl_cd_nm
           FROM ez_ct.ct_cc_dtl_c
           WHERE clnt_cd = ub.clnt_cd
             AND cc_cd = '1104'
             AND use_yn = 'Y'
             AND cc_dtl_cd = ub.cc_jgrd_cd
       ) AS ccJgrdNm,
       REPLACE(ub.mbl_telno, '-', '') AS mblTelno,
       ub.eml_adr AS emlAdr,
       ub.ceil_aply_obj_yn AS ceilAplyObjYn,
       ub.ceil_aply_strt_mm AS ceilAplyStrtMm,
       CASE
           WHEN EXISTS (
               SELECT 1
               FROM ez_ct.ct_fam_mem_b
               WHERE user_key = ub.user_key
           )
           THEN 'Y'
           ELSE 'N'
       END AS famMemJoinYn,
       CASE
           WHEN ct.join_apv_yn = 'N'
             OR ct.cc_hlof_st_cd = '1000'
           THEN 'N'
           ELSE ct.join_apv_yn
       END AS joinApvYn,
       COALESCE(WFP.wfpAsgPnt::TEXT, '') AS wfpAsgPnt,
       COALESCE(WFP.wfpUsePnt::TEXT, '') AS wfpUsePnt,
       COALESCE(WFP.wfpRmnPnt::TEXT, '') AS wfpRmnPnt,
       COALESCE(SPP.sppAsgPnt::TEXT, '') AS sppAsgPnt,
       COALESCE(SPP.sppRmnPnt::TEXT, '') AS sppRmnPnt,
       COALESCE(SPP.sppUsePnt::TEXT, '') AS sppUsePnt
FROM
(
    /* ============================================================
       1. 대상 임직원을 먼저 정렬/제한
          → 이후 WFP/SPP LATERAL은 최대 50명만 수행
       ============================================================ */
    SELECT *
    FROM ez_ct.vw_ct_usr_b
    WHERE clnt_cd = 'hyundai-steel'
      AND test_usr_yn = 'N'
      AND use_yn = 'Y'
    ORDER BY last_mod_dtm DESC, user_key
    LIMIT 50
) ub
LEFT OUTER JOIN ez_ct.ct_usr_b ct
  ON ct.clnt_cd = 'hyundai-steel'
 AND ub.user_key = ct.user_key
INNER JOIN ez_ct.ct_clnt_b cb
  ON ub.clnt_cd = cb.clnt_cd
LEFT OUTER JOIN ez_ct.ct_cc_dtl_c cdc
  ON cb.clnt_cd = cdc.clnt_cd
 AND cdc.cc_cd = '1401'
 AND cdc.cc_dtl_cd = ub.cc_hlof_st_cd
/* ================================================================
   2. 선복(WFP)
      기존 로직 유지
      단, ub가 50건으로 제한된 후 실행
   ================================================================ */
LEFT OUTER JOIN LATERAL
(
    SELECT
        SUM(
            CASE
                WHEN WSP_TYP_CD = 'I'
                THEN WSP_AMT
                ELSE 0
            END
        ) AS wfpAsgPnt,
        SUM(COALESCE(wsp_amt, 0)) AS wfpRmnPnt,
        ABS(
            SUM(
                CASE
                    WHEN WSP_TYP_CD = 'U'
                    THEN WSP_AMT
                    ELSE 0
                END
            )
        ) AS wfpUsePnt,
        USER_KEY
    FROM EZ_CT.CP_USR_WFP_B
    WHERE CLNT_CD = ub.CLNT_CD
      AND USER_KEY = ub.user_key
      AND RGM_OPEN_CLSG_NO =
          (
              SELECT EZ_CT.FN_GET_RGM_OPEN_CLSG_NO(
                         'hyundai-steel',
                         'ONLN'
                     )
          )
    GROUP BY USER_KEY
) WFP
  ON WFP.USER_KEY = ub.USER_KEY
/* ================================================================
   3. 특복(SPP)
      기존 SPP별 USE_D LATERAL을 제거하고
      CP_SPP_USE_D를 SPP 번호 + USER_KEY 기준으로 집계
      핵심:
        기존
        CP_SPP_B  → 각 SPP마다 CP_SPP_USE_D 반복조회
        변경
        CP_SPP_B
          LEFT JOIN
        CP_SPP_USE_D 집계
          ↓
        USER_KEY 기준 GROUP BY
      또한 ub가 최대 50건이므로 SPP 대상도 최대 50명
   ================================================================ */
LEFT OUTER JOIN LATERAL
(
    SELECT
        spp.user_key,
        COALESCE(
            SUM(spp.ASG_WSP_AMT),
            0
        ) AS sppAsgPnt,
        COALESCE(
            SUM(spp.ASG_WSP_AMT),
            0
        )
        -
        COALESCE(
            SUM(use.useSum),
            0
        ) AS sppRmnPnt,
        COALESCE(
            SUM(use.useSum),
            0
        ) AS sppUsePnt
    FROM EZ_CT.CP_SPP_B spp
    /* ------------------------------------------------------------
       CP_SPP_USE_D를 SPP별로 집계
       ------------------------------------------------------------ */
    LEFT OUTER JOIN LATERAL
    (
        SELECT
            u.usr_spp_no,
            u.user_key,
            SUM(u.use_pnt) AS useSum
        FROM EZ_CT.CP_SPP_USE_D u
        WHERE u.usr_spp_no = spp.usr_spp_no
          AND u.user_key = spp.user_key
        GROUP BY
            u.usr_spp_no,
            u.user_key
    ) use
      ON TRUE
    /* ------------------------------------------------------------
       특복 코드 존재/사용가능 여부 확인
       ------------------------------------------------------------ */
    INNER JOIN EZ_CT.CP_WSP_C code
      ON code.wsp_cd = spp.spp_wsp_cd
     AND code.clnt_cd = spp.clnt_cd
     AND code.wsp_div_cd = '2000'
     AND code.use_yn = 'Y'
    WHERE spp.user_key = ub.user_key
      AND spp.clnt_cd = ub.clnt_cd
      AND spp.cncl_yn <> 'Y'
      AND TO_CHAR(
              NOW(),
              'YYYYMMDDHH24MISS'
          )
          BETWEEN spp.use_poss_strt_dtm
              AND spp.use_poss_end_dtm
      AND TO_CHAR(
              NOW(),
              'YYYYMMDDHH24MISS'
          )
          BETWEEN code.wsp_use_poss_strt_dtm
              AND code.wsp_use_poss_end_dtm
    GROUP BY
        spp.user_key
) SPP
  ON SPP.user_key = ub.user_key;