/* com.ezwelesp.bo.hcas.customer.rest.employee.mapper.query.HcasMemberQueryMapper.selectBoardMemberAndEmployeeList */
SELECT /* 임직원 목록 조회(HIMS) HcasMemberQueryMapper.selectBoardMemberAndEmployeeList */
    	       ub.clnt_cd AS clntCd,
	           cb.clnt_nm AS clntNm,
	           ub.user_key AS userKey,
	           ub.usr_nm AS usrNm,
	           ub.self_crtf_bymd_dt AS selfCrtfBymdDt,
	           ub.self_crtf_gndr_nval AS selfCrtfGndrNval,
	           CONCAT(ub.self_crtf_bymd_dt, '-', ub.self_crtf_gndr_nval) as bymdg,
	           ub.usr_id AS usrId,
	           ub.clnt_empno AS clntEmpno,
	           ub.cc_hlof_st_cd AS ccHlofStCd,
	           COALESCE((select comm_dtl_cd_nm from ez_ct.ct_cc_dtl_c c where c.clnt_cd = ub.clnt_cd and cc_cd = '1401' and cc_dtl_cd = ub.cc_hlof_st_cd), '') as ccHlofStNm,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1401' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_hlof_st_cd) AS ccHlofStNm,
	           ub.use_yn AS useYn,
	           ub.epm_shap_cd AS epmShapCd,
	           cdc.lgin_poss_yn AS lginPossYn,
	           cdc.wfp_use_poss_yn AS wfpUsePossYn,
	           cdc.spp_use_poss_yn AS sppUsePossYn,
	           ub.self_crtf_yn AS selfCrtfYn,
	           ub.cc_br_cd AS ccBrCd,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1101' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_br_cd) AS ccBrNm,
	           ub.cc_dept_cd AS ccDeptCd,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1102' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_dept_cd) AS ccDeptNm,
	           ub.cc_team_cd AS ccTeamCd,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1103' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_team_cd) AS ccTeamNm,
	           ub.cc_part_cd AS ccPartCd,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1107' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_part_cd) AS ccPartNm,
	           ub.cc_jgrd_cd AS ccJgrdCd,
	           (SELECT comm_dtl_cd_nm AS commDtlCdNm FROM ez_ct.ct_cc_dtl_c WHERE clnt_cd = ub.clnt_cd AND cc_cd = '1104' AND use_yn = 'Y' and cc_dtl_cd = ub.cc_jgrd_cd) AS ccJgrdNm,
	           replace(ub.mbl_telno, '-', '') AS mblTelno,
	           ub.eml_adr AS emlAdr,
	           ub.ceil_aply_obj_yn AS ceilAplyObjYn,
	           ub.ceil_aply_strt_mm AS ceilAplyStrtMm,
	           case when exists (select 1 from ez_ct.ct_fam_mem_b where user_key = ub.user_key) THEN 'Y'
	                ELSE 'N' END AS famMemJoinYn,
	           CASE WHEN ct.join_apv_yn = 'N' or ct.cc_hlof_st_cd = '1000' THEN 'N'
	                ELSE ct.join_apv_yn
	            END AS joinApvYn,
	           COALESCE(WFP.wfpAsgPnt::TEXT, '') as wfpAsgPnt,
	           COALESCE(WFP.wfpUsePnt::TEXT, '') as wfpUsePnt,
	           COALESCE(WFP.wfpRmnPnt::TEXT, '') as wfpRmnPnt,
	           COALESCE(spp.sppAsgPnt::TEXT, '') as sppAsgPnt,
	           COALESCE(spp.sppRmnPnt::TEXT, '') as sppRmnPnt,
	           COALESCE(spp.sppUsePnt::TEXT, '') as sppUsePnt
	             
	    FROM ez_ct.vw_ct_usr_b ub
	    LEFT OUTER JOIN ez_ct.ct_usr_b ct
	      on ct.clnt_cd = 'hyundai-steel'
	     and ub.user_key = ct.user_key
	    INNER JOIN ez_ct.ct_clnt_b cb
          ON ub.clnt_cd = cb.clnt_cd
	    LEFT OUTER JOIN ez_ct.ct_cc_dtl_c cdc
          ON cb.clnt_cd = cdc.clnt_cd
         AND cdc.cc_cd = '1401'
         AND cdc.cc_dtl_cd = ub.cc_hlof_st_cd
         
	    -- 선복 조회
        left outer JOIN lateral(
                SELECT
                    SUM(case when WSP_TYP_CD = 'I' then WSP_AMT else 0 end) AS wfpAsgPnt ,
                    sum(COALESCE(wsp_amt, 0)) as wfpRmnPnt,
                    ABS(SUM(case when WSP_TYP_CD = 'U' then WSP_AMT else 0 end)) AS wfpUsePnt ,
                    USER_KEY
                FROM EZ_CT.CP_USR_WFP_B
                WHERE CLNT_CD = ub.CLNT_CD
                    and USER_KEY = ub.user_key
                    AND RGM_OPEN_CLSG_NO = (select EZ_CT.FN_GET_RGM_OPEN_CLSG_NO('hyundai-steel', 'ONLN'))
                GROUP BY USER_KEY
            ) WFP ON WFP.USER_KEY = ub.USER_KEY
         -- 특복 조회
	     left outer join lateral (
	        	select
		        	spp.user_key,
		        	COALESCE(SUM(spp.ASG_WSP_AMT), 0) AS sppAsgPnt,
		        	COALESCE(SUM(spp.ASG_WSP_AMT), 0) - sum(COALESCE(use.useSum, 0)) AS sppRmnPnt,
                    COALESCE(sum(use.useSum), 0) as sppUsePnt
	        	from EZ_CT.CP_SPP_B spp
		        	left outer join lateral (
	                	select
	                		sum(use_pnt) as useSum
	                	from ez_ct.CP_SPP_USE_D u
	                	WHERE u.usr_spp_no = spp.usr_spp_no
                            and u.user_key = spp.user_key
	                	group by u.user_key
	            	) use on 1=1
	            	left outer join ez_ct.CP_WSP_ASG_B asg on asg.wsp_asg_no = spp.wsp_asg_no
	            	JOIN ez_ct.cp_wsp_c code ON code.wsp_cd = spp.spp_wsp_cd and code.clnt_cd = spp.clnt_cd and code.wsp_div_cd = '2000' and code.USE_YN = 'Y'
            	where spp.user_key = ub.user_key
            	    and spp.clnt_cd = ub.CLNT_CD
            	    and spp.CNCL_YN != 'Y'
            	    and TO_CHAR(NOW(),'YYYYMMDDHH24MISS') BETWEEN spp.USE_POSS_STRT_DTM AND spp.USE_POSS_END_DTM
           			AND TO_CHAR(NOW(),'YYYYMMDDHH24MISS') BETWEEN code.WSP_USE_POSS_STRT_DTM AND code.WSP_USE_POSS_END_DTM
                    group by spp.user_key
	      ) spp on spp.user_key = ub.user_key    
	    WHERE ub.clnt_cd = 'hyundai-steel'
	    AND ub.test_usr_yn = 'N'
	    AND ub.use_yn = 'Y'
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     	         
	     
	         
	     
	     
	    ORDER BY ub.last_mod_dtm DESC, ub.user_key LIMIT 50