create index concurrently cm_push_snd_obj_d_ix02
on ez_cm.cm_push_snd_obj_d
   (clnt_cd, user_key, push_trms_seq, push_seq);

analyze ez_cm.cm_push_snd_obj_d;

--DROP INDEX CONCURRENTLY IF EXISTS cm_push_snd_obj_d_ix02;

/* CscoMap.getClientPushSend */
        SELECT *
          FROM (
              SELECT
                     ROW_NUMBER() OVER(ORDER BY send_dt
                      DESC 
                    ) PAGE_INDX
                   , COUNT(*) OVER () TOTL_
                   , INNER_.*
                FROM (
        SELECT *
          FROM (
                  SELECT CPB.PUSH_SEQ AS MSG_SEQ
                     , TO_CHAR(AM.SEND_SDATE,'YYYYMMDDHH24MISS') AS SEND_DT
                     , CPB.MSG_TTL AS MSG_TTL
                     , CPB.MSG_CNTN AS SEND_MSG
                     , CPSOD.CLNT_CD AS CLIENT_CD
                     , CPB.MBL_OS_DIV_CD AS OS_TYPE
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'push_infm_typ_cd' AND COMM_DTL_CD = CPB.PUSH_INFM_TYP_CD) AS INFM_TYPE_NM
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'push_snd_shap_cd' AND COMM_DTL_CD = CPB.PUSH_SND_SHAP_CD) AS SND_SHAP_NM
                     , (SELECT COMM_DTL_CD_NM FROM EZ_CM.CM_COMM_DTL_C WHERE COMM_CD = 'mbl_os_div_cd' AND COMM_DTL_CD = CPB.MBL_OS_DIV_CD) AS OS_TYPE_NM
                     , CASE
                     	WHEN AM.FPSTEP = 'C' THEN '발송완료'
				        WHEN AM.FPSTEP = 'R' THEN '발송대기'
				        WHEN AM.FPSTEP = 'S' THEN '발송중'
				        WHEN (AM.FPSTEP = 'T' OR AM.FPSTEP = 'F') THEN '실패'
				        ELSE ''
				       END AS MSG_SND_ST_NM
                     , CPB.IMG_FILE_NM AS IMG_TITLE
                     , CPB.IMG_FILE_PATH AS IMG_FILE_PATH
                  FROM EZ_CM.CM_PUSH_B CPB
                 INNER JOIN (
                 	SELECT PUSH_SEQ, PUSH_TRMS_SEQ, CLNT_CD, USER_KEY
                 	FROM EZ_CM.CM_PUSH_SND_OBJ_D
                 	WHERE CLNT_CD = 'withus'
                 	) CPSOD ON CPB.PUSH_SEQ = CPSOD.PUSH_SEQ
				 INNER JOIN EZ_FPUSH.AGPUSH_MASTER AM
					ON CPSOD.PUSH_TRMS_SEQ = AM.SERIALNUM
                 WHERE CPB.DEL_YN = 'N'
                 	AND AM.SEND_SDATE BETWEEN TO_TIMESTAMP('20260811' || '000000','YYYYMMDDHH24MISS') AND TO_TIMESTAMP('20260910' || '235959', 'YYYYMMDDHH24MISS') --바인드변수(발송시작일/발송종료일) 
                      AND CPSOD.USER_KEY = '1013413507' -- 바인드변수(유저키)
--                      AND CPB.PUSH_INFM_TYP_CD = 'S' -- 바인드변수(푸시알림유형코드)
--				 	AND CPB.PUSH_SND_SHAP_CD = 'GEN_SND' -- 바인드변수(푸시발송형태코드)
               )
--                WHERE (MSG_TTL LIKE '%' || '광고' || '%' OR SEND_MSG LIKE '%' || '광고' || '%') -- 바인드변수(검색내용)
                       ) INNER_
                ) BASE_
         WHERE BASE_.PAGE_INDX  >=  CAST('1' AS BIGINT)
           AND BASE_.PAGE_INDX  <  CAST('11' AS BIGINT)
        ORDER BY PAGE_INDX asc
        ;