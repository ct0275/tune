CREATE INDEX CONCURRENTLY ad_ldg_apl_dt_limt_d_ix01
ON ez_pd.ad_ldg_apl_dt_limt_d
   (ldg_clnt_rgm_no, ldg_grp_cd, acpt_limt_dt);
   
DROP INDEX CONCURRENTLY IF EXISTS ad_ldg_apl_dt_limt_d_ix01;

/* com.ezwelesp.fo.lodgement.rest.bizcommon.mapper.query.LodgeLimitQueryMapper.selectLdgAplDtLimtDetailList */
/* 숙박신청일자제한상세 목록 조회 */
	 	select ladld.ldg_clnt_rgm_no			/* 숙박고객사제도번호 */
		     , ladld.ldg_grp_cd			 		/* 숙박그룹코드 */
		     , ladld.accm_br_cd			 		/* 숙박시설지점코드 */
		     , ladld.room_cd			 		/* 객실코드 */
		     , ladld.acpt_limt_dt			 	/* 접수제한일자 */
		     , ladld.ldg_grp_limt_typ_cd		/* 숙박그룹제한유형코드(LDGR:숙박그룹, ACBR:숙박시설지점, ROOM:객실) */
		     , ladld.ldg_grp_limt_msg_cd		/* 숙박그룹제한메시지코드 */
		     , llmc.msg_cntn					/* 메시지내용 */
		     , ladld.clnd_show_cntn			 	/* 달력표시내용 */
		  from ez_pd.ad_ldg_apl_dt_limt_d ladld		/** 숙박신청일자제한상세 */
		  left outer join ez_pd.ad_ldg_limt_msg_c llmc 	/** 숙박제한메시지코드 */
		    on ladld.ldg_grp_limt_msg_cd = llmc.ldg_grp_limt_msg_cd 
		 where ladld.ldg_clnt_rgm_no = 3226
		   and ladld.ldg_grp_cd = '1001'
		   and ladld.acpt_limt_dt between '20261017' and to_char(to_date('20261018', 'yyyymmdd') -1, 'yyyymmdd')